import { db } from './server/db.ts';
import * as fs from 'fs';
import * as path from 'path';

// استيراد جداول قاعدة البيانات
import { 
  clients, 
  bookings, 
  payments, 
  receivables, 
  invoices,
  drivers,
  vehicles,
  externalPartners
} from './drizzle/schema.ts';

// دالة لتحويل البيانات إلى CSV
function toCSV(data, headers) {
  if (!data || data.length === 0) {
    return headers.join(',');
  }
  
  const csvHeaders = headers.join(',');
  const csvRows = data.map(row => {
    return headers.map(header => {
      const value = row[header];
      if (value === null || value === undefined) return '';
      if (typeof value === 'string' && value.includes(',')) {
        return `"${value.replace(/"/g, '""')}"`;
      }
      return value;
    }).join(',');
  });
  
  return [csvHeaders, ...csvRows].join('\n');
}

async function exportData() {
  try {
    console.log('جاري تصدير البيانات...');
    
    // تصدير العملاء
    const clientsData = await db.select().from(clients);
    const clientsCSV = toCSV(clientsData, ['id', 'name', 'phone', 'email', 'address', 'type', 'createdAt']);
    fs.writeFileSync(path.join('/home/ubuntu/tourism-transport-system/backups', 'clients.csv'), clientsCSV, 'utf-8');
    console.log('✅ تم تصدير العملاء');
    
    // تصدير الحجوزات
    const bookingsData = await db.select().from(bookings);
    const bookingsCSV = toCSV(bookingsData, ['id', 'bookingNumber', 'clientId', 'customerName', 'pickupLocation', 'dropoffLocation', 'pickupDateTime', 'fare', 'status', 'createdAt']);
    fs.writeFileSync(path.join('/home/ubuntu/tourism-transport-system/backups', 'bookings.csv'), bookingsCSV, 'utf-8');
    console.log('✅ تم تصدير الحجوزات');
    
    // تصدير الدفعات
    const paymentsData = await db.select().from(payments);
    const paymentsCSV = toCSV(paymentsData, ['id', 'clientId', 'amount', 'paymentMethod', 'status', 'createdAt']);
    fs.writeFileSync(path.join('/home/ubuntu/tourism-transport-system/backups', 'payments.csv'), paymentsCSV, 'utf-8');
    console.log('✅ تم تصدير الدفعات');
    
    // تصدير الذمم
    const receivablesData = await db.select().from(receivables);
    const receivablesCSV = toCSV(receivablesData, ['id', 'clientId', 'bookingId', 'amount', 'status', 'createdAt']);
    fs.writeFileSync(path.join('/home/ubuntu/tourism-transport-system/backups', 'receivables.csv'), receivablesCSV, 'utf-8');
    console.log('✅ تم تصدير الذمم');
    
    // تصدير الفواتير
    const invoicesData = await db.select().from(invoices);
    const invoicesCSV = toCSV(invoicesData, ['id', 'invoiceNumber', 'clientId', 'amount', 'status', 'createdAt']);
    fs.writeFileSync(path.join('/home/ubuntu/tourism-transport-system/backups', 'invoices.csv'), invoicesCSV, 'utf-8');
    console.log('✅ تم تصدير الفواتير');
    
    // تصدير السائقين
    const driversData = await db.select().from(drivers);
    const driversCSV = toCSV(driversData, ['id', 'name', 'phone', 'email', 'licenseNumber', 'status', 'createdAt']);
    fs.writeFileSync(path.join('/home/ubuntu/tourism-transport-system/backups', 'drivers.csv'), driversCSV, 'utf-8');
    console.log('✅ تم تصدير السائقين');
    
    // تصدير المركبات
    const vehiclesData = await db.select().from(vehicles);
    const vehiclesCSV = toCSV(vehiclesData, ['id', 'plateNumber', 'model', 'capacity', 'status', 'createdAt']);
    fs.writeFileSync(path.join('/home/ubuntu/tourism-transport-system/backups', 'vehicles.csv'), vehiclesCSV, 'utf-8');
    console.log('✅ تم تصدير المركبات');
    
    // تصدير الشركاء الخارجيين
    const partnersData = await db.select().from(externalPartners);
    const partnersCSV = toCSV(partnersData, ['id', 'name', 'type', 'contactPerson', 'phone', 'email', 'createdAt']);
    fs.writeFileSync(path.join('/home/ubuntu/tourism-transport-system/backups', 'external_partners.csv'), partnersCSV, 'utf-8');
    console.log('✅ تم تصدير الشركاء الخارجيين');
    
    console.log('\n✅ تم تصدير جميع البيانات بنجاح!');
    console.log('📁 الملفات موجودة في: /home/ubuntu/tourism-transport-system/backups/');
    
  } catch (error) {
    console.error('❌ خطأ أثناء التصدير:', error);
  }
}

exportData();
