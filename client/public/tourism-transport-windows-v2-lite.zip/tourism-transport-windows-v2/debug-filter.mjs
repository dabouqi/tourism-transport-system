// اختبار منطق الفلتر
const now = new Date();
console.log('=== Current Date ===');
console.log('now (UTC):', now.toISOString());
console.log('now (local):', now.toLocaleString());

// الطريقة الحالية (المُطبقة)
const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
console.log('\n=== Today (using UTC) ===');
console.log('today:', today.toISOString());

// حساب نطاق يناير 2026
const thisMonth_start = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1));
const thisMonth_end = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() + 1, 1));

console.log('\n=== This Month Range ===');
console.log('Start:', thisMonth_start.toISOString());
console.log('End:', thisMonth_end.toISOString());
console.log('Start time:', thisMonth_start.getTime());
console.log('End time:', thisMonth_end.getTime());

// اختبار مع حجوزات من يناير
const testBookings = [
  { id: 1, dropoffDateTime: new Date('2026-01-15T14:30:00Z') },
  { id: 2, dropoffDateTime: new Date('2026-01-20T10:00:00Z') },
  { id: 3, dropoffDateTime: new Date('2025-12-20T10:00:00Z') },
  { id: 4, dropoffDateTime: '2026-01-15T14:30:00Z' }, // string format
];

console.log('\n=== Testing Bookings ===');
testBookings.forEach(booking => {
  const dropoffDate = new Date(booking.dropoffDateTime);
  console.log(`\nBooking ${booking.id}:`);
  console.log('  dropoffDateTime:', booking.dropoffDateTime);
  console.log('  parsed:', dropoffDate.toISOString());
  
  const bookingDateOnly = new Date(Date.UTC(
    dropoffDate.getUTCFullYear(),
    dropoffDate.getUTCMonth(),
    dropoffDate.getUTCDate()
  ));
  
  console.log('  bookingDateOnly:', bookingDateOnly.toISOString());
  console.log('  bookingTime:', bookingDateOnly.getTime());
  
  const inRange = bookingDateOnly.getTime() >= thisMonth_start.getTime() && 
                  bookingDateOnly.getTime() < thisMonth_end.getTime();
  console.log('  In range?', inRange);
});
