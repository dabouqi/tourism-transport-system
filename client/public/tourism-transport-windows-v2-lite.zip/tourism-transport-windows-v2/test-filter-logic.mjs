// اختبار شامل لمنطق الفلتر
import { drizzle } from "drizzle-orm/mysql2/http";
import { eq, and, gte, lte, lt, desc } from "drizzle-orm";
import * as schema from "./drizzle/schema.js";

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error("DATABASE_URL not set");
  process.exit(1);
}

const db = drizzle(DATABASE_URL);

console.log("=== Fetching bookings from database ===\n");

try {
  const bookings = await db.select().from(schema.bookings).orderBy(desc(schema.bookings.pickupDateTime));
  
  console.log(`Total bookings: ${bookings.length}\n`);
  
  if (bookings.length > 0) {
    console.log("First 3 bookings:");
    bookings.slice(0, 3).forEach((booking, i) => {
      console.log(`\n${i + 1}. Booking ID: ${booking.id}`);
      console.log(`   Booking Number: ${booking.bookingNumber}`);
      console.log(`   pickupDateTime: ${booking.pickupDateTime}`);
      console.log(`   dropoffDateTime: ${booking.dropoffDateTime}`);
      console.log(`   Status: ${booking.status}`);
      
      // Test filtering logic
      const now = new Date();
      const dropoffDate = new Date(booking.dropoffDateTime);
      console.log(`   dropoffDate parsed: ${dropoffDate.toISOString()}`);
      console.log(`   Is past booking? ${dropoffDate <= now}`);
      
      // Test "this month" filter
      const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
      const thisMonth_start = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1));
      const thisMonth_end = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth() + 1, 1));
      
      const bookingDateOnly = new Date(Date.UTC(
        dropoffDate.getUTCFullYear(),
        dropoffDate.getUTCMonth(),
        dropoffDate.getUTCDate()
      ));
      
      const inThisMonth = bookingDateOnly.getTime() >= thisMonth_start.getTime() && 
                          bookingDateOnly.getTime() < thisMonth_end.getTime();
      
      console.log(`   bookingDateOnly: ${bookingDateOnly.toISOString()}`);
      console.log(`   This month range: ${thisMonth_start.toISOString()} to ${thisMonth_end.toISOString()}`);
      console.log(`   In this month? ${inThisMonth}`);
    });
  }
  
  // Count bookings by month
  console.log("\n\n=== Bookings by month ===");
  const bookingsByMonth = {};
  bookings.forEach(booking => {
    const date = new Date(booking.dropoffDateTime);
    const key = `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
    bookingsByMonth[key] = (bookingsByMonth[key] || 0) + 1;
  });
  
  Object.entries(bookingsByMonth).sort().forEach(([month, count]) => {
    console.log(`${month}: ${count} bookings`);
  });
  
} catch (error) {
  console.error("Error:", error.message);
  process.exit(1);
}
