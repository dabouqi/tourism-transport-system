import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";
import * as dbReports from "./db-reports";
import { clientsRouter, receivablesRouter, paymentsRouter } from "./routers-clients-payments";
import { exportData, importData } from "./backup";

// Helper to check admin role
const adminProcedure = publicProcedure.use(({ ctx, next }) => {
  if (!ctx.user || ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

// Helper to check operations manager or admin role
const operationsProcedure = publicProcedure.use(({ ctx, next }) => {
  if (!ctx.user || (ctx.user.role !== "admin" && ctx.user.role !== "operations_manager")) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Operations access required" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ DASHBOARD ============
  dashboard: router({
    getStats: publicProcedure.query(async () => {
      const [todayBookings, activeVehicles, todayRevenue, pendingOperations] = await Promise.all([
        db.getTodayBookingsCount(),
        db.getActiveVehiclesCount(),
        db.getTodayRevenue(),
        db.getPendingOperationsCount(),
      ]);

      return {
        todayBookings,
        activeVehicles,
        todayRevenue,
        pendingOperations,
      };
    }),

    getRecentAlerts: publicProcedure.query(async () => {
      const alerts = await db.getUnreadAlerts();
      return alerts.slice(0, 5);
    }),

    monthlyFinancialSummary: publicProcedure
      .input(z.object({ year: z.number().optional(), month: z.number().optional() }))
      .query(async ({ input }) => {
        return await db.getMonthlyFinancialSummary(input.year, input.month);
      }),

    compareFinancialData: publicProcedure
      .input(z.object({ periods: z.array(z.object({ year: z.number(), month: z.number() })) }))
      .query(async ({ input }) => {
        return await db.getFinancialComparison(input.periods);
      }),

    getTotalReceivables: publicProcedure.query(async () => {
      return await db.getTotalReceivables();
    }),
  }),

  // ============ VEHICLES ============
  vehicles: router({
    list: publicProcedure.query(() => db.getVehicles()),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) =>
      db.getVehicleById(input.id)
    ),

    create: operationsProcedure
      .input(
        z.object({
          licensePlate: z.string().min(1),
          vehicleType: z.string().min(1),
          model: z.string().min(1),
          year: z.number(),
          capacity: z.number().min(1),
          fuelLevel: z.number().optional(),
          purchaseDate: z.date().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await db.createVehicle({
          ...input,
          status: "available",
          fuelLevel: (input.fuelLevel || 100).toString(),
        });
        return { success: true };
      }),

    update: operationsProcedure
      .input(
        z.object({
          id: z.number(),
          licensePlate: z.string().optional(),
          vehicleType: z.string().optional(),
          model: z.string().optional(),
          year: z.number().optional(),
          capacity: z.number().optional(),
          status: z.enum(["available", "in_trip", "maintenance", "inactive"]).optional(),
          fuelLevel: z.number().optional(),
          nextMaintenanceDate: z.date().optional(),
          mileage: z.number().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(({ input }) => {
        const { id, fuelLevel, ...data } = input;
        const updateData = {
          ...data,
          ...(fuelLevel !== undefined && { fuelLevel: fuelLevel.toString() }),
        };
        return db.updateVehicle(id, updateData);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteVehicle(input.id)),

    getTracking: publicProcedure
      .input(z.object({ vehicleId: z.number() }))
      .query(async ({ input }) => {
        const vehicle = await db.getVehicleById(input.vehicleId);
        if (!vehicle) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Vehicle not found" });
        }
        const latestLocation = await db.getLatestVehicleLocation(input.vehicleId);
        if (!latestLocation) {
          throw new TRPCError({ code: "NOT_FOUND", message: "No tracking data available" });
        }
        return {
          id: vehicle.id,
          licensePlate: vehicle.licensePlate,
          status: vehicle.status,
          latitude: latestLocation.latitude,
          longitude: latestLocation.longitude,
          speed: latestLocation.speed,
          heading: latestLocation.heading,
          altitude: latestLocation.altitude,
          accuracy: latestLocation.accuracy,
          lastUpdated: latestLocation.timestamp,
        };
      }),

    getMultipleTracking: publicProcedure
      .input(z.object({ vehicleIds: z.array(z.number()) }))
      .query(async ({ input }) => {
        const vehicles = await Promise.all(
          input.vehicleIds.map((id) => db.getVehicleById(id))
        );
        const trackingData = await Promise.all(
          input.vehicleIds.map(async (vehicleId) => {
            const vehicle = vehicles.find((v) => v?.id === vehicleId);
            if (!vehicle) return null;
            const latestLocation = await db.getLatestVehicleLocation(vehicleId);
            if (!latestLocation) return null;
            return {
              id: vehicle.id,
              licensePlate: vehicle.licensePlate,
              status: vehicle.status,
              latitude: latestLocation.latitude,
              longitude: latestLocation.longitude,
              speed: latestLocation.speed,
              heading: latestLocation.heading,
              altitude: latestLocation.altitude,
              accuracy: latestLocation.accuracy,
              lastUpdated: latestLocation.timestamp,
            };
          })
        );
        return trackingData.filter((t) => t !== null);
      }),
  }),

  // ============ DRIVERS ============
  drivers: router({
    list: publicProcedure.query(() => db.getDrivers()),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) =>
      db.getDriverById(input.id)
    ),

    create: operationsProcedure
      .input(
        z.object({
          name: z.string().min(1),
          phone: z.string().min(1),
          email: z.string().email().optional(),
          licenseNumber: z.string().min(1),
          licenseExpiry: z.date(),
          joinDate: z.date(),
          salary: z.number().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { salary, ...data } = input;
        await db.createDriver({
          ...data,
          status: "available",
          salary: salary ? salary.toString() : null,
        });
        return { success: true };
      }),

    update: operationsProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          phone: z.string().optional(),
          email: z.string().optional(),
          licenseNumber: z.string().optional(),
          licenseExpiry: z.date().optional(),
          status: z.enum(["available", "on_trip", "on_leave", "inactive"]).optional(),
          salary: z.number().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(({ input }) => {
        const { id, salary, ...data } = input;
        const updateData = {
          ...data,
          ...(salary !== undefined && { salary: salary.toString() }),
        };
        return db.updateDriver(id, updateData);
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteDriver(input.id)),
  }),

  // ============ BOOKINGS ============
  bookings: router({
    list: publicProcedure.query(() => db.getBookings()),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(({ input }) =>
      db.getBookingById(input.id)
    ),

    getWithTracking: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const booking = await db.getBookingById(input.id);
        if (!booking) return null;

        let vehicle = null;
        let tracking = null;

        if (booking.vehicleId) {
          vehicle = await db.getVehicleById(booking.vehicleId);
          tracking = await db.getLatestVehicleTracking(booking.vehicleId);
        }

        return {
          booking,
          vehicle,
          tracking,
        };
      }),

    create: publicProcedure
      .input(
        z.object({
          bookingNumber: z.string().optional(),
          clientId: z.number().nullable().optional(),
          customerName: z.string().optional(),
          customerPhone: z.string().optional(),
          customerEmail: z.string().optional(),
          pickupLocation: z.string().optional(),
          dropoffLocation: z.string().optional(),
          pickupDateTime: z.date().optional(),
          dropoffDateTime: z.date().optional(),
          numberOfPassengers: z.number().optional(),
          fare: z.number().optional(),
          bookingSource: z.enum(["internal", "talixo", "get_transfer", "transfeero", "other"]).optional(),
          status: z.enum(["pending", "confirmed", "in_progress", "completed", "cancelled"]).optional(),
          notes: z.string().optional(),
          vehicleId: z.number().nullable().optional(),
          driverId: z.number().nullable().optional(),
          paymentStatus: z.enum(["unpaid", "partial", "paid"]).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const bookingNumber = input.bookingNumber || `BK-${Date.now()}`;
        await db.createBooking({
          ...input,
          bookingNumber,
          status: input.status || "pending",
          paymentStatus: input.paymentStatus || "unpaid",
        });
        return { success: true };
      }),

    update: operationsProcedure
      .input(
        z.object({
          id: z.number(),
          bookingNumber: z.string().optional(),
          clientId: z.number().nullable().optional(),
          customerName: z.string().optional(),
          customerPhone: z.string().optional(),
          customerEmail: z.string().optional(),
          pickupLocation: z.string().optional(),
          dropoffLocation: z.string().optional(),
          pickupDateTime: z.date().optional(),
          dropoffDateTime: z.date().optional(),
          numberOfPassengers: z.number().optional(),
          fare: z.number().optional(),
          bookingSource: z.enum(["internal", "talixo", "get_transfer", "transfeero", "other"]).optional(),
          status: z.enum(["pending", "confirmed", "in_progress", "completed", "cancelled"]).optional(),
          notes: z.string().optional(),
          vehicleId: z.number().nullable().optional(),
          driverId: z.number().nullable().optional(),
          paymentStatus: z.enum(["unpaid", "partial", "paid"]).optional(),
        })
      )
      .mutation(({ input }) => {
        const { id, ...data } = input;
        return db.updateBooking(id, data);
      }),

    delete: operationsProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteBooking(input.id)),

    getByStatus: publicProcedure
      .input(z.object({ status: z.string() }))
      .query(async ({ input }) => {
        const allBookings = await db.getBookings();
        return allBookings.filter((b) => b.status === input.status);
      }),

    getStats: publicProcedure.query(async () => {
      const allBookings = await db.getBookings();
      const total = allBookings.length;
      const pending = allBookings.filter((b) => b.status === "pending").length;
      const completed = allBookings.filter((b) => b.status === "completed").length;
      const cancelled = allBookings.filter((b) => b.status === "cancelled").length;

      return { total, pending, completed, cancelled };
    }),
  }),

  // ============ ALERTS ============
  alerts: router({
    getUnread: publicProcedure.query(() => db.getUnreadAlerts()),

    getAll: publicProcedure.query(() => db.getAlerts()),

    markAsRead: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.markAlertAsRead(input.id)),

    create: operationsProcedure
      .input(
        z.object({
          alertType: z.enum(["maintenance_due", "no_driver_assigned", "low_fuel", "booking_created", "urgent_maintenance"]),
          title: z.string(),
          message: z.string(),
          relatedBookingId: z.number().nullable().optional(),
          relatedVehicleId: z.number().nullable().optional(),
          relatedDriverId: z.number().nullable().optional(),
        })
      )
      .mutation(({ input }) => db.createAlert(input)),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteAlert(input.id)),
  }),

  // ============ TRANSACTIONS ============
  transactions: router({
    list: publicProcedure.query(() => db.getTransactions()),

    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      const allTransactions = await db.getTransactions();
      return allTransactions.find((t) => t.id === input.id) || null;
    }),

    getByType: publicProcedure
      .input(z.object({ type: z.enum(["revenue", "expense"]) }))
      .query(async ({ input }) => {
        const allTransactions = await db.getTransactions();
        return allTransactions.filter((t) => t.transactionType === input.type);
      }),

    getByDateRange: publicProcedure
      .input(z.object({ startDate: z.date(), endDate: z.date() }))
      .query(async ({ input }) => {
        const allTransactions = await db.getTransactions();
        return allTransactions.filter((t) => {
          const txDate = new Date(t.transactionDate);
          return txDate >= input.startDate && txDate <= input.endDate;
        });
      }),

    create: operationsProcedure
      .input(
        z.object({
          transactionType: z.enum(["revenue", "expense"]),
          category: z.string().min(1),
          amount: z.number().min(0),
          description: z.string().optional(),
          transactionDate: z.date(),
        })
      )
      .mutation(({ input }) => db.createTransaction({
        ...input,
        amount: input.amount.toString(),
      })),

    update: operationsProcedure
      .input(
        z.object({
          id: z.number(),
          transactionType: z.enum(["revenue", "expense"]),
          category: z.string().min(1),
          amount: z.number().min(0),
          description: z.string().optional(),
          transactionDate: z.date(),
        })
      )
      .mutation(({ input }) => db.updateTransaction(input.id, {
        transactionType: input.transactionType,
        category: input.category,
        amount: input.amount.toString(),
        description: input.description,
        transactionDate: input.transactionDate,
      })),

    delete: operationsProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteTransaction(input.id)),
  }),

  // ============ VEHICLE TRACKING ============
  tracking: router({
    getLatest: publicProcedure
      .input(z.object({ vehicleId: z.number() }))
      .query(async ({ input }) => {
        const tracking = await db.getLatestVehicleTracking(input.vehicleId);
        return tracking || null;
      }),

    recordLocation: operationsProcedure
      .input(
        z.object({
          vehicleId: z.number(),
          latitude: z.number(),
          longitude: z.number(),
          speed: z.number().optional(),
          heading: z.number().optional(),
          accuracy: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await db.createVehicleTracking({
          vehicleId: input.vehicleId,
          latitude: input.latitude.toString(),
          longitude: input.longitude.toString(),
          speed: input.speed ? input.speed.toString() : null,
          heading: input.heading ? input.heading.toString() : null,
          accuracy: input.accuracy ? input.accuracy.toString() : null,
          timestamp: new Date(),
        });
      }),

    getTelecomcubeVehicles: publicProcedure
      .query(async () => {
        try {
          const vehicles = await db.getVehicles();
          return {
            success: true,
            vehicles: vehicles.map((v) => ({
              id: v.id.toString(),
              name: v.licensePlate,
              latitude: 31.945,
              longitude: 35.927,
              speed: 45,
              lastUpdate: new Date().toISOString(),
              status: v.status || 'active'
            }))
          };
        } catch (error) {
          throw new TRPCError({
            code: 'INTERNAL_SERVER_ERROR',
            message: 'فشل في الحصول على بيانات المركبات من Telecomcube'
          });
        }
      }),
  }),

  // ============ ADVANCED FINANCIAL MANAGEMENT ============
  financials: router({
    getIncomeCategories: publicProcedure.query(async () => {
      const categories = await db.getIncomeCategories();
      return categories || [];
    }),
    
    getExpenseCategories: publicProcedure.query(async () => {
      const categories = await db.getExpenseCategories();
      return categories || [];
    }),
    
    createIncomeCategory: adminProcedure
      .input(z.object({ name: z.string(), description: z.string().optional(), color: z.string().optional(), icon: z.string().optional() }))
      .mutation(({ input }) => db.createIncomeCategory(input)),
    
    createExpenseCategory: adminProcedure
      .input(z.object({ name: z.string(), description: z.string().optional(), color: z.string().optional(), icon: z.string().optional() }))
      .mutation(({ input }) => db.createExpenseCategory(input)),
    
    getFinancialSummary: publicProcedure
      .input(z.object({ year: z.number(), month: z.number().optional() }))
      .query(async ({ input }) => {
        const summary = await db.getFinancialSummary(input.year, input.month);
        return summary || null;
      }),
    
    calculateMonthlyFinancialSummary: publicProcedure
      .input(z.object({ year: z.number(), month: z.number() }))
      .query(async ({ input }) => {
        const summary = await db.calculateMonthlyFinancialSummary(input.year, input.month);
        return summary || null;
      }),
    
    getRevenueByCategory: publicProcedure
      .input(z.object({ startDate: z.date(), endDate: z.date() }))
      .query(async ({ input }) => {
        const revenue = await db.getRevenueByCategory(input.startDate, input.endDate);
        return revenue || [];
      }),
    
    getExpensesByCategory: publicProcedure
      .input(z.object({ startDate: z.date(), endDate: z.date() }))
      .query(async ({ input }) => {
        const expenses = await db.getExpensesByCategory(input.startDate, input.endDate);
        return expenses || [];
      }),
    
    getExpensesByVehicle: publicProcedure
      .input(z.object({ startDate: z.date(), endDate: z.date() }))
      .query(async ({ input }) => {
        const expenses = await db.getExpensesByVehicle(input.startDate, input.endDate);
        return expenses || [];
      }),
    
    getExpensesByDriver: publicProcedure
      .input(z.object({ startDate: z.date(), endDate: z.date() }))
      .query(async ({ input }) => {
        const expenses = await db.getExpensesByDriver(input.startDate, input.endDate);
        return expenses || [];
      }),
    
    getMonthlyFinancialTrend: publicProcedure
      .input(z.object({ year: z.number() }))
      .query(async ({ input }) => {
        const trend = await db.getMonthlyFinancialTrend(input.year);
        return trend || [];
      }),
    
    getPendingTransactions: publicProcedure.query(async () => {
      const pending = await db.getPendingTransactions();
      return pending || [];
    }),
    
    getBookingIncomeStatus: publicProcedure
      .input(z.object({ bookingId: z.number() }))
      .query(async ({ input }) => {
        const status = await db.getBookingIncomeStatus(input.bookingId);
        return status || null;
      }),
  }),

  partners: router({
    getAll: publicProcedure.query(async () => {
      const partners = await db.getExternalPartners();
      return partners || [];
    }),
    
    getRevenueByPartner: publicProcedure
      .input(z.object({ startDate: z.date(), endDate: z.date() }))
      .query(async ({ input }) => {
        const revenue = await db.getRevenueByPartner(input.startDate, input.endDate);
        return revenue || [];
      }),
    
    getTotalRevenueWithPartners: publicProcedure
      .input(z.object({ startDate: z.date(), endDate: z.date() }))
      .query(async ({ input }) => {
        const revenue = await db.getRevenueByPartner(input.startDate, input.endDate);
        const total = revenue.reduce((sum, item) => sum + (parseFloat(item.totalRevenue || "0")), 0);
        return { total, breakdown: revenue };
      }),
    
    getBookingsBySource: publicProcedure
      .input(z.object({ source: z.string() }))
      .query(({ input }) => db.getBookingsBySource(input.source)),
  }),

  clients: clientsRouter,
  receivables: receivablesRouter,
  payments: paymentsRouter,

  invoices: router({
    getAll: publicProcedure.query(async () => {
      const invoices = await db.getInvoices();
      return invoices || [];
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const invoice = await db.getInvoiceById(input.id);
        return invoice || null;
      }),
    
    getByClientId: publicProcedure
      .input(z.object({ clientId: z.number() }))
      .query(async ({ input }) => {
        const invoices = await db.getInvoicesByClientId(input.clientId);
        return invoices || [];
      }),
    
    getByStatus: publicProcedure
      .input(z.object({ status: z.string() }))
      .query(async ({ input }) => {
        const invoices = await db.getInvoicesByStatus(input.status);
        return invoices || [];
      }),
    
    create: operationsProcedure
      .input(z.object({
        invoiceNumber: z.string(),
        clientId: z.number(),
        receivableId: z.number(),
        bookingId: z.number(),
        issueDate: z.date(),
        dueDate: z.date().nullable(),
        totalAmount: z.number(),
        paidAmount: z.number(),
        remainingAmount: z.number(),
        status: z.enum(["draft", "sent", "viewed", "paid", "overdue", "cancelled"]),
        paymentMethod: z.enum(["cash", "card", "transfer", "check", "other"]).nullable(),
        notes: z.string().nullable(),
      }))
      .mutation(({ input }) => {
        const data = {
          ...input,
          totalAmount: input.totalAmount.toString(),
          paidAmount: input.paidAmount.toString(),
          remainingAmount: input.remainingAmount.toString(),
        };
        return db.createInvoice(data as any);
      }),
    
    update: operationsProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          invoiceNumber: z.string().optional(),
          clientId: z.number().nullable().optional(),
          receivableId: z.number().optional(),
          bookingId: z.number().optional(),
          issueDate: z.date().optional(),
          dueDate: z.date().nullable().optional(),
          totalAmount: z.number().optional(),
          paidAmount: z.number().optional(),
          remainingAmount: z.number().optional(),
          status: z.enum(["draft", "sent", "viewed", "paid", "overdue", "cancelled"]).optional(),
          paymentMethod: z.enum(["cash", "card", "transfer", "check", "other"]).nullable().optional(),
          notes: z.string().nullable().optional(),
        }),
      }))
      .mutation(({ input }) => {
        const updateData: any = { ...input.data };
        if (input.data.totalAmount !== undefined) {
          updateData.totalAmount = input.data.totalAmount.toString();
        }
        if (input.data.paidAmount !== undefined) {
          updateData.paidAmount = input.data.paidAmount.toString();
        }
        if (input.data.remainingAmount !== undefined) {
          updateData.remainingAmount = input.data.remainingAmount.toString();
        }
        return db.updateInvoice(input.id, updateData);
      }),
    
    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => db.deleteInvoice(input.id)),
  }),

  // ============ REPORTS ============
  reports: router({
    monthlyReport: publicProcedure
      .input(z.object({ year: z.number(), month: z.number().min(1).max(12) }))
      .query(async ({ input }) => {
        try {
          return await dbReports.getMonthlyReport(input.year, input.month);
        } catch (error) {
          console.error("Error getting monthly report:", error);
          return null;
        }
      }),

    clientDetailedReport: publicProcedure
      .input(z.object({ clientId: z.number() }))
      .query(async ({ input }) => {
        try {
          return await dbReports.getClientDetailedReport(input.clientId);
        } catch (error) {
          console.error("Error getting client detailed report:", error);
          return null;
        }
      }),

    clientMonthlyReport: publicProcedure
      .input(z.object({ clientId: z.number(), year: z.number(), month: z.number().min(1).max(12) }))
      .query(async ({ input }) => {
        try {
          return await dbReports.getClientMonthlyReport(input.clientId, input.year, input.month);
        } catch (error) {
          console.error("Error getting client monthly report:", error);
          return null;
        }
      }),
  }),

  // ============ BACKUP & RESTORE ============
  backup: router({
    export: adminProcedure.query(async () => {
      try {
        const data = await exportData();
        return { success: true, data };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "خطأ غير معروف",
        });
      }
    }),

    import: adminProcedure
      .input(z.object({
        version: z.string(),
        timestamp: z.string(),
        data: z.object({
          bookings: z.array(z.any()).optional(),
          transactions: z.array(z.any()).optional(),
          receivables: z.array(z.any()).optional(),
          payments: z.array(z.any()).optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        try {
          const result = await importData(input as any);
          return result;
        } catch (error) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: error instanceof Error ? error.message : "خطأ غير معروف",
          });
        }
      }),
  }),

})

export type AppRouter = typeof appRouter;
