import { drizzle } from "drizzle-orm/mysql2";
import { eq, and, gte, lte, lt, desc, isNotNull, sql } from "drizzle-orm";
import {
  InsertUser,
  users,
  vehicles,
  drivers,
  bookings,
  maintenanceRecords,
  alerts,
  transactions,
  vehicleTracking,
  incomeCategories,
  expenseCategories,
  transactionsV2,
  financialSummaries,
  externalPartners,
  partnerTransactions,
  clients,
  receivables,
  payments,
  invoices,
  vehicleLocations,
  Client,
  InsertClient,
  Receivable,
  InsertReceivable,
  Payment,
  InsertPayment,
  Invoice,
  InsertInvoice,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ VEHICLES ============

export async function getVehicles() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(vehicles).orderBy(desc(vehicles.createdAt));
}

export async function getVehicleById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(vehicles).where(eq(vehicles.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createVehicle(data: typeof vehicles.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(vehicles).values(data);
  return result;
}

export async function updateVehicle(id: number, data: Partial<typeof vehicles.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(vehicles).set(data).where(eq(vehicles.id, id));
}

export async function deleteVehicle(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(vehicles).where(eq(vehicles.id, id));
}

// ============ DRIVERS ============

export async function getDrivers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(drivers).orderBy(desc(drivers.createdAt));
}

export async function getDriverById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(drivers).where(eq(drivers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDriver(data: typeof drivers.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(drivers).values(data);
}

export async function updateDriver(id: number, data: Partial<typeof drivers.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(drivers).set(data).where(eq(drivers.id, id));
}

export async function deleteDriver(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(drivers).where(eq(drivers.id, id));
}

// ============ BOOKINGS ============

export async function getBookings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bookings).orderBy(desc(bookings.pickupDateTime));
}

export async function getBookingById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getTodayBookingsCount() {
  const db = await getDb();
  if (!db) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const result = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(bookings)
    .where(
      and(
        gte(bookings.pickupDateTime, today),
        lt(bookings.pickupDateTime, tomorrow)
      )
    );

  return result[0]?.count || 0;
}

export async function createBooking(data: typeof bookings.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة");
  
  try {
    // تحويل التواريخ بشكل صحيح
    const processedData = {
      ...data,
      clientId: data.clientId || null,
      pickupDateTime: data.pickupDateTime ? new Date(data.pickupDateTime) : new Date(),
      dropoffDateTime: data.dropoffDateTime ? new Date(data.dropoffDateTime) : null,
      programEndDate: data.programEndDate ? new Date(data.programEndDate) : null,
      fare: data.fare ? String(data.fare) : '0',
    };
    
    const result = await db.insert(bookings).values(processedData as any);
    
    // Get the inserted booking ID from the result
    // Result is an array where result[0] contains the ResultSetHeader with insertId
    let bookingId: number | undefined;
    if (Array.isArray(result) && result.length > 0 && (result[0] as any).insertId) {
      bookingId = (result[0] as any).insertId;
    } else if ((result as any).insertId) {
      bookingId = (result as any).insertId;
    }
    
    console.log('[createBooking] bookingId extracted:', bookingId);
    
    // Create receivable for the booking (with or without client)
    if (data.fare && bookingId) {
      try {
        const fareAmount = Number(data.fare) || 0;
        
        // If no client is assigned, create a default client first
        let clientId = data.clientId;
        if (!clientId) {
          // Create a temporary/default client for this booking
          const defaultClient = await db.insert(clients).values({
            name: data.customerName || "عميل بدون تحديد",
            type: "individual",
            phone: data.customerPhone || undefined,
            email: data.customerEmail || undefined,
            address: data.pickupLocation || undefined,
          });
          
          // Extract the client ID from the result
          if (Array.isArray(defaultClient) && defaultClient.length > 0 && (defaultClient[0] as any).insertId) {
            clientId = (defaultClient[0] as any).insertId;
          } else if ((defaultClient as any).insertId) {
            clientId = (defaultClient as any).insertId;
          }
          
          console.log('[createBooking] Default client created:', clientId);
        }
        
        // Create receivable for the client
        if (clientId) {
          await db.insert(receivables).values({
            clientId: clientId,
            bookingId: bookingId,
            amount: fareAmount.toString(),
            paidAmount: "0",
            remainingAmount: fareAmount.toString(),
            dueDate: data.pickupDateTime || new Date(),
            status: "pending",
            notes: `ذمة من حجز: ${data.bookingNumber}`,
          });
          
          console.log('[createBooking] Receivable created for client:', clientId);
        }
      } catch (receivableError) {
        console.error("خطأ في إنشاء الذمة:", receivableError);
      }
    }
    
    // Register the booking as revenue (only once)
    if (data.fare && bookingId) {
      try {
        const fareAmount = Number(data.fare) || 0;
        
        // Check if transaction already exists for this booking
        const existingTransaction = await db
          .select()
          .from(transactions)
          .where(and(eq(transactions.bookingId, bookingId), eq(transactions.transactionType, 'revenue')))
          .limit(1);
        
        if (existingTransaction.length === 0) {
          await db.insert(transactions).values({
            transactionType: "revenue",
            category: "حجز سياحي",
            amount: fareAmount.toString(),
            description: `حجز جديد: ${data.customerName}`,
            bookingId: bookingId,
            isFromBooking: true,
            transactionDate: data.pickupDateTime || new Date(),
          });
        }
      } catch (transactionError) {
        console.error("خطأ في تسجيل الدخل:", transactionError);
      }
    }
    
    return result;
  } catch (error) {
    console.error("خطأ في إنشاء الحجز:", error);
    
    if (error instanceof Error && error.message.includes('FOREIGN KEY')) {
      throw new Error('العميل المحدد غير موجود');
    }
    
    throw error;
  }
}

export async function updateBooking(id: number, data: Partial<typeof bookings.$inferInsert>) {
  // Prevent updating transactions from bookings - they are read-only
  // Only allow updating booking data, not the transaction
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  try {
    // 1. جلب الحجز القديم للمقارنة
    const oldBooking = await db
      .select()
      .from(bookings)
      .where(eq(bookings.id, id))
      .limit(1);
    
    if (oldBooking.length === 0) {
      throw new Error('Booking not found');
    }

    // 2. Process data to convert dates and fare
    const processedData: any = { ...data };
    if (data.pickupDateTime) {
      processedData.pickupDateTime = new Date(data.pickupDateTime);
    }
    if (data.dropoffDateTime) {
      processedData.dropoffDateTime = new Date(data.dropoffDateTime);
    }
    if (data.programEndDate) {
      processedData.programEndDate = new Date(data.programEndDate);
    }
    if (data.fare) {
      processedData.fare = String(data.fare);
    }
    
    // 3. تحديث بيانات الحجز
    await db.update(bookings).set(processedData).where(eq(bookings.id, id));
    
    // 4. التحقق من تغيير السعر
    const oldFare = Number(oldBooking[0].fare) || 0;
    const newFare = Number(data.fare) || 0;
    
    if (data.fare !== undefined && oldFare !== newFare) {
      // 5. تحديث الذمم (Receivables)
      const receivable = await db
        .select()
        .from(receivables)
        .where(eq(receivables.bookingId, id))
        .limit(1);
      
      if (receivable.length > 0) {
        const currentPaid = Number(receivable[0].amount) - Number(receivable[0].remainingAmount);
        const newRemainingAmount = newFare - currentPaid;
        
        await db
          .update(receivables)
          .set({
            amount: String(newFare),
            remainingAmount: String(Math.max(0, newRemainingAmount)),
            status: newRemainingAmount <= 0 ? 'paid' : receivable[0].status
          })
          .where(eq(receivables.id, receivable[0].id));
      } else if (newFare > 0 && oldBooking[0].clientId) {
        // إنشاء ذمة جديدة إذا لم تكن موجودة
        await db.insert(receivables).values({
          clientId: oldBooking[0].clientId,
          bookingId: id,
          amount: String(newFare),
          remainingAmount: String(newFare),
          paidAmount: '0',
          status: 'pending'
        });
      }
      
      // 6. تحديث الفواتير (Invoices)
      const invoice = await db
        .select()
        .from(invoices)
        .where(eq(invoices.bookingId, id))
        .limit(1);
      
      if (invoice.length > 0) {
        const currentPaid = Number(invoice[0].totalAmount) - Number(invoice[0].remainingAmount);
        const newRemainingAmount = newFare - currentPaid;
        
        await db
          .update(invoices)
          .set({
            totalAmount: String(newFare),
            remainingAmount: String(Math.max(0, newRemainingAmount)),
            status: newRemainingAmount <= 0 ? 'paid' : invoice[0].status
          })
          .where(eq(invoices.id, invoice[0].id));
      }
      
      // 7. تحديث المعاملات المالية (Transactions)
      const revenueTransaction = await db
        .select()
        .from(transactions)
        .where(
          and(
            eq(transactions.bookingId, id),
            eq(transactions.transactionType, 'revenue')
          )
        )
        .limit(1);
      
      if (revenueTransaction.length > 0) {
        await db
          .update(transactions)
          .set({ amount: String(newFare) })
          .where(eq(transactions.id, revenueTransaction[0].id));
      } else if (newFare > 0) {
        // إنشاء معاملة جديدة إذا لم تكن موجودة
        await db.insert(transactions).values({
          transactionType: 'revenue',
          category: 'حجز',
          amount: String(newFare),
          description: `Revenue from booking #${id}`,
          bookingId: id,
          isFromBooking: true,
          transactionDate: new Date()
        });
      }
    }
    
    return { success: true, priceChanged: oldFare !== newFare };
  } catch (error) {
    console.error('Error updating booking:', error);
    throw error;
  }
}

export async function deleteBooking(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(transactions).where(eq(transactions.bookingId, id));
  
  return db.delete(bookings).where(eq(bookings.id, id));
}

// ============ MAINTENANCE RECORDS ============

export async function getMaintenanceRecords() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(maintenanceRecords).orderBy(desc(maintenanceRecords.createdAt));
}

export async function getMaintenanceRecordsByVehicleId(vehicleId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(maintenanceRecords)
    .where(eq(maintenanceRecords.vehicleId, vehicleId))
    .orderBy(desc(maintenanceRecords.createdAt));
}

export async function createMaintenanceRecord(data: typeof maintenanceRecords.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Create maintenance record
  const result = await db.insert(maintenanceRecords).values(data);
  
  // Add cost to expenses automatically if cost exists
  if (data.cost && Number(data.cost) > 0) {
    try {
      // تسجيل المصروف في جدول transactions الصحيح
      await db.insert(transactions).values({
        transactionType: "expense",
        category: "صيانة المركبات",
        amount: data.cost,
        description: `Vehicle Maintenance: ${data.maintenanceType}`,
        vehicleId: data.vehicleId,
        transactionDate: new Date(),
        isFromBooking: false,
      });
      console.log(`[Maintenance Expense] Added expense for vehicle ${data.vehicleId}: ${data.cost} د.ا`);
    } catch (error) {
      console.error("Error adding maintenance expense:", error);
    }
  }
  
  return result;
}

export async function updateMaintenanceRecord(
  id: number,
  data: Partial<typeof maintenanceRecords.$inferInsert>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(maintenanceRecords).set(data).where(eq(maintenanceRecords.id, id));
}

// ============ ALERTS ============

export async function getAlerts() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(alerts).orderBy(desc(alerts.createdAt));
}

export async function getUnreadAlerts() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(alerts)
    .where(eq(alerts.isRead, false))
    .orderBy(desc(alerts.createdAt));
}

export async function createAlert(data: typeof alerts.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(alerts).values(data);
}

export async function markAlertAsRead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(alerts).set({ isRead: true }).where(eq(alerts.id, id));
}

// ============ TRANSACTIONS ============

export async function getTransactions(clientId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  let whereCondition = undefined;
  if (clientId) {
    whereCondition = eq(transactions.clientId, clientId);
  }
  
  const result = await db
    .select({
      id: transactions.id,
      transactionType: transactions.transactionType,
      category: transactions.category,
      amount: transactions.amount,
      description: transactions.description,
      bookingId: transactions.bookingId,
      clientId: transactions.clientId,
      vehicleId: transactions.vehicleId,
      driverId: transactions.driverId,
      isFromBooking: transactions.isFromBooking,
      transactionDate: transactions.transactionDate,
      createdAt: transactions.createdAt,
      updatedAt: transactions.updatedAt,
      bookingDate: sql`COALESCE(${bookings.pickupDateTime}, ${transactions.createdAt})`,
    })
    .from(transactions)
    .leftJoin(bookings, eq(transactions.bookingId, bookings.id))
    .where(whereCondition)
    .orderBy(desc(transactions.transactionDate));
  
  return result;
}

export async function getTodayRevenue() {
  const db = await getDb();
  if (!db) return 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const result = await db
    .select({ total: sql<string>`SUM(amount)` })
    .from(transactions)
    .where(
      and(
        eq(transactions.transactionType, "revenue"),
        gte(transactions.transactionDate, today),
        lte(transactions.transactionDate, tomorrow)
      )
    );

  return parseFloat(result[0]?.total || "0");
}

export async function createTransaction(data: typeof transactions.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(transactions).values(data);
}

// ============ VEHICLE TRACKING ============

export async function getLatestVehicleTracking(vehicleId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(vehicleTracking)
    .where(eq(vehicleTracking.vehicleId, vehicleId))
    .orderBy(desc(vehicleTracking.timestamp))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createVehicleTracking(data: typeof vehicleTracking.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(vehicleTracking).values(data);
}

export async function getActiveVehiclesCount() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(vehicles)
    .where(eq(vehicles.status, "available"));

  return result[0]?.count || 0;
}

export async function getPendingOperationsCount() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(bookings)
    .where(eq(bookings.status, "pending"));

  return result[0]?.count || 0;
}

// ============ UPDATE & DELETE FUNCTIONS ============

export async function updateTransaction(id: number, data: Partial<typeof transactions.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(transactions).set(data).where(eq(transactions.id, id));
}

export async function deleteTransaction(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Get the transaction to check if it has a bookingId
  const transaction = await db.select().from(transactions).where(eq(transactions.id, id)).limit(1);
  
  if (transaction.length > 0 && transaction[0].bookingId) {
    // Delete the associated booking
    await db.delete(bookings).where(eq(bookings.id, transaction[0].bookingId));
  }
  
  // Delete the transaction
  return db.delete(transactions).where(eq(transactions.id, id));
}

export async function updateAlert(id: number, data: Partial<typeof alerts.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(alerts).set(data).where(eq(alerts.id, id));
}

export async function deleteMaintenanceRecord(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Get maintenance record to find related expense
  const records = await db.select().from(maintenanceRecords).where(eq(maintenanceRecords.id, id));
  const record = records[0];
  
  // Delete related expense from transactionsV2 if cost exists
  if (record && record.cost) {
    try {
      // Delete only the expense related to this specific maintenance
      const expenseDescription = `Vehicle Maintenance: ${record.maintenanceType}`;
      await db.delete(transactionsV2).where(
        and(
          eq(transactionsV2.transactionType, "expense"),
          eq(transactionsV2.vehicleId, record.vehicleId),
          eq(transactionsV2.description, expenseDescription)
        )
      );
    } catch (error) {
      console.error("Error deleting related expense:", error);
    }
  }
  
  // Delete maintenance record
  return db.delete(maintenanceRecords).where(eq(maintenanceRecords.id, id));
}

export async function deleteAlert(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(alerts).where(eq(alerts.id, id));
}


// ============ ADVANCED FINANCIAL FUNCTIONS ============

export async function getIncomeCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(incomeCategories);
}

export async function getExpenseCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(expenseCategories);
}

export async function createIncomeCategory(data: typeof incomeCategories.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(incomeCategories).values(data);
}

export async function createExpenseCategory(data: typeof expenseCategories.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(expenseCategories).values(data);
}

export async function getFinancialSummary(year: number, month?: number) {
  const db = await getDb();
  if (!db) return null;
  
  const where = month 
    ? and(eq(financialSummaries.year, year), eq(financialSummaries.month, month))
    : and(eq(financialSummaries.year, year), eq(financialSummaries.month, 0));
  
  const result = await db.select().from(financialSummaries).where(where).limit(1);
  return result[0] || null;
}

export async function calculateMonthlyFinancialSummary(year: number, month: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59);
  
  // Get revenue
  const revenueResult = await db
    .select({ total: sql<number>`SUM(amount)` })
    .from(transactionsV2)
    .where(
      and(
        eq(transactionsV2.transactionType, "revenue"),
        gte(transactionsV2.transactionDate, startDate),
        lte(transactionsV2.transactionDate, endDate)
      )
    );
  
  // Get expenses
  const expenseResult = await db
    .select({ total: sql<number>`SUM(amount)` })
    .from(transactionsV2)
    .where(
      and(
        eq(transactionsV2.transactionType, "expense"),
        gte(transactionsV2.transactionDate, startDate),
        lte(transactionsV2.transactionDate, endDate)
      )
    );
  
  const totalRevenue = revenueResult[0]?.total || 0;
  const totalExpenses = expenseResult[0]?.total || 0;
  const netProfit = totalRevenue - totalExpenses;
  const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
  
  return {
    year,
    month,
    totalRevenue,
    totalExpenses,
    netProfit,
    profitMargin,
  };
}

export async function getRevenueByCategory(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select({
      categoryId: transactionsV2.incomeCategoryId,
      categoryName: incomeCategories.name,
      total: sql<number>`SUM(${transactionsV2.amount})`,
      count: sql<number>`COUNT(*)`,
      color: incomeCategories.color,
    })
    .from(transactionsV2)
    .leftJoin(incomeCategories, eq(transactionsV2.incomeCategoryId, incomeCategories.id))
    .where(
      and(
        eq(transactionsV2.transactionType, "revenue"),
        gte(transactionsV2.transactionDate, startDate),
        lte(transactionsV2.transactionDate, endDate)
      )
    )
    .groupBy(transactionsV2.incomeCategoryId);
}

export async function getExpensesByCategory(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select({
      categoryId: transactionsV2.expenseCategoryId,
      categoryName: expenseCategories.name,
      total: sql<number>`SUM(${transactionsV2.amount})`,
      count: sql<number>`COUNT(*)`,
      color: expenseCategories.color,
    })
    .from(transactionsV2)
    .leftJoin(expenseCategories, eq(transactionsV2.expenseCategoryId, expenseCategories.id))
    .where(
      and(
        eq(transactionsV2.transactionType, "expense"),
        gte(transactionsV2.transactionDate, startDate),
        lte(transactionsV2.transactionDate, endDate)
      )
    )
    .groupBy(transactionsV2.expenseCategoryId);
}

export async function getExpensesByVehicle(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select({
      vehicleId: transactionsV2.vehicleId,
      vehicleName: vehicles.licensePlate,
      total: sql<number>`SUM(${transactionsV2.amount})`,
      count: sql<number>`COUNT(*)`,
    })
    .from(transactionsV2)
    .leftJoin(vehicles, eq(transactionsV2.vehicleId, vehicles.id))
    .where(
      and(
        eq(transactionsV2.transactionType, "expense"),
        gte(transactionsV2.transactionDate, startDate),
        lte(transactionsV2.transactionDate, endDate),
        isNotNull(transactionsV2.vehicleId)
      )
    )
    .groupBy(transactionsV2.vehicleId);
}

export async function getExpensesByDriver(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select({
      driverId: transactionsV2.driverId,
      driverName: drivers.name,
      total: sql<number>`SUM(${transactionsV2.amount})`,
      count: sql<number>`COUNT(*)`,
    })
    .from(transactionsV2)
    .leftJoin(drivers, eq(transactionsV2.driverId, drivers.id))
    .where(
      and(
        eq(transactionsV2.transactionType, "expense"),
        gte(transactionsV2.transactionDate, startDate),
        lte(transactionsV2.transactionDate, endDate),
        isNotNull(transactionsV2.driverId)
      )
    )
    .groupBy(transactionsV2.driverId);
}

export async function getMonthlyFinancialTrend(year: number) {
  const db = await getDb();
  if (!db) return [];
  
  const months = Array.from({ length: 12 }, (_, i) => i + 1);
  const trends = [];
  
  for (const month of months) {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59);
    
    const revenueResult = await db
      .select({ total: sql<number>`SUM(amount)` })
      .from(transactionsV2)
      .where(
        and(
          eq(transactionsV2.transactionType, "revenue"),
          gte(transactionsV2.transactionDate, startDate),
          lte(transactionsV2.transactionDate, endDate)
        )
      );
    
    const expenseResult = await db
      .select({ total: sql<number>`SUM(amount)` })
      .from(transactionsV2)
      .where(
        and(
          eq(transactionsV2.transactionType, "expense"),
          gte(transactionsV2.transactionDate, startDate),
          lte(transactionsV2.transactionDate, endDate)
        )
      );
    
    trends.push({
      month,
      revenue: revenueResult[0]?.total || 0,
      expenses: expenseResult[0]?.total || 0,
    });
  }
  
  return trends;
}

export async function getPendingTransactions() {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(transactionsV2)
    .where(eq(transactionsV2.status, "pending"))
    .orderBy(desc(transactionsV2.transactionDate));
}

export async function getBookingIncomeStatus(bookingId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select()
    .from(transactionsV2)
    .where(
      and(
        eq(transactionsV2.bookingId, bookingId),
        eq(transactionsV2.transactionType, "revenue")
      )
    )
    .limit(1);
  
  return result[0] || null;
}

export async function getMonthlyFinancialSummary(year?: number, month?: number) {
  const db = await getDb();
  if (!db) return { totalIncome: 0, totalExpenses: 0, netProfit: 0, incomeByCategory: [], expenseByCategory: [] };
  
  // Use current month if not specified
  const now = new Date();
  const targetYear = year || now.getFullYear();
  const targetMonth = month || now.getMonth() + 1;
  
  const startDate = new Date(targetYear, targetMonth - 1, 1);
  const endDate = new Date(targetYear, targetMonth, 0, 23, 59, 59);
  
  // Get total income
  const incomeResult = await db
    .select({ total: sql<number>`COALESCE(SUM(amount), 0)` })
    .from(transactions)
    .where(
      and(
        eq(transactions.transactionType, "revenue"),
        gte(transactions.transactionDate, startDate),
        lte(transactions.transactionDate, endDate)
      )
    );
  
  // Get total expenses
  const expenseResult = await db
    .select({ total: sql<number>`COALESCE(SUM(amount), 0)` })
    .from(transactions)
    .where(
      and(
        eq(transactions.transactionType, "expense"),
        gte(transactions.transactionDate, startDate),
        lte(transactions.transactionDate, endDate)
      )
    );
  
  // Get income by category
  const incomeByCategory = await db
    .select({
      category: transactions.category,
      total: sql<number>`COALESCE(SUM(amount), 0)`,
    })
    .from(transactions)
    .where(
      and(
        eq(transactions.transactionType, "revenue"),
        gte(transactions.transactionDate, startDate),
        lte(transactions.transactionDate, endDate)
      )
    )
    .groupBy(transactions.category);
  
  // Get expenses by category
  const expenseByCategory = await db
    .select({
      category: transactions.category,
      total: sql<number>`COALESCE(SUM(amount), 0)`,
    })
    .from(transactions)
    .where(
      and(
        eq(transactions.transactionType, "expense"),
        gte(transactions.transactionDate, startDate),
        lte(transactions.transactionDate, endDate)
      )
    )
    .groupBy(transactions.category);
  
  const totalIncome = incomeResult[0]?.total || 0;
  const totalExpenses = expenseResult[0]?.total || 0;
  const netProfit = totalIncome - totalExpenses;
  
  return {
    totalIncome,
    totalExpenses,
    netProfit,
    incomeByCategory,
    expenseByCategory,
    month: targetMonth,
    year: targetYear,
  };
}

export async function getFinancialComparison(periods: Array<{ year: number; month: number }>) {
  const db = await getDb();
  if (!db) return [];
  
  const comparisons = [];
  
  for (const period of periods) {
    const startDate = new Date(period.year, period.month - 1, 1);
    const endDate = new Date(period.year, period.month, 0, 23, 59, 59);
    
    // Get total income
    const incomeResult = await db
      .select({ total: sql<number>`COALESCE(SUM(amount), 0)` })
      .from(transactions)
      .where(
        and(
          eq(transactions.transactionType, "revenue"),
          gte(transactions.transactionDate, startDate),
          lte(transactions.transactionDate, endDate)
        )
      );
    
    // Get total expenses
    const expenseResult = await db
      .select({ total: sql<number>`COALESCE(SUM(amount), 0)` })
      .from(transactions)
      .where(
        and(
          eq(transactions.transactionType, "expense"),
          gte(transactions.transactionDate, startDate),
          lte(transactions.transactionDate, endDate)
        )
      );
    
    // Get income by category
    const incomeByCategory = await db
      .select({
        category: transactions.category,
        total: sql<number>`COALESCE(SUM(amount), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.transactionType, "revenue"),
          gte(transactions.transactionDate, startDate),
          lte(transactions.transactionDate, endDate)
        )
      )
      .groupBy(transactions.category);
    
    // Get expenses by category
    const expenseByCategory = await db
      .select({
        category: transactions.category,
        total: sql<number>`COALESCE(SUM(amount), 0)`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.transactionType, "expense"),
          gte(transactions.transactionDate, startDate),
          lte(transactions.transactionDate, endDate)
        )
      )
      .groupBy(transactions.category);
    
    const totalIncome = incomeResult[0]?.total || 0;
    const totalExpenses = expenseResult[0]?.total || 0;
    const netProfit = totalIncome - totalExpenses;
    
    comparisons.push({
      period: `${period.month}/${period.year}`,
      month: period.month,
      year: period.year,
      totalIncome,
      totalExpenses,
      netProfit,
      incomeByCategory,
      expenseByCategory,
    });
  }
  
  return comparisons;
}

export async function getTotalReceivables() {
  // استخدام نفس الدالة من تقرير الذمم للحصول على البيانات الصحيحة
  const stats = await getReceivablesStats();
  return stats.remainingAmount;
}




// ============ EXTERNAL PARTNERS FUNCTIONS ============

export async function getExternalPartners() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(externalPartners);
}

export async function getExternalPartnerByCode(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(externalPartners).where(eq(externalPartners.code, code)).limit(1);
  return result[0] || null;
}

export async function createExternalPartner(data: typeof externalPartners.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(externalPartners).values(data);
}

export async function updateExternalPartner(id: number, data: Partial<typeof externalPartners.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(externalPartners).set(data).where(eq(externalPartners.id, id));
}

export async function getPartnerTransactions(partnerId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  if (partnerId) {
    return db.select().from(partnerTransactions).where(eq(partnerTransactions.partnerId, partnerId));
  }
  return db.select().from(partnerTransactions);
}

export async function createPartnerTransaction(data: typeof partnerTransactions.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(partnerTransactions).values(data);
}

export async function getPartnerEarnings(partnerId: number, startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db
    .select({
      totalAmount: sql<number>`SUM(${partnerTransactions.amount})`,
      totalCommission: sql<number>`SUM(${partnerTransactions.commission})`,
      totalNetAmount: sql<number>`SUM(${partnerTransactions.netAmount})`,
      transactionCount: sql<number>`COUNT(*)`,
    })
    .from(partnerTransactions)
    .where(
      and(
        eq(partnerTransactions.partnerId, partnerId),
        gte(partnerTransactions.transactionDate, startDate),
        lte(partnerTransactions.transactionDate, endDate)
      )
    );
  
  return result[0] || null;
}

export async function getPartnerTransactionsByStatus(partnerId: number, status: string) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(partnerTransactions)
    .where(
      and(
        eq(partnerTransactions.partnerId, partnerId),
        eq(partnerTransactions.status, status as any)
      )
    );
}

export async function getBookingsBySource(source: string) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select()
    .from(bookings)
    .where(eq(bookings.bookingSource, source as any))
    .orderBy(desc(bookings.pickupDateTime));
}

export async function getRevenueByPartner(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return db
    .select({
      partnerId: externalPartners.id,
      partnerName: externalPartners.name,
      partnerCode: externalPartners.code,
      totalAmount: sql<number>`SUM(${partnerTransactions.amount})`,
      totalCommission: sql<number>`SUM(${partnerTransactions.commission})`,
      totalNetAmount: sql<number>`SUM(${partnerTransactions.netAmount})`,
      transactionCount: sql<number>`COUNT(*)`,
    })
    .from(partnerTransactions)
    .leftJoin(externalPartners, eq(partnerTransactions.partnerId, externalPartners.id))
    .where(
      and(
        gte(partnerTransactions.transactionDate, startDate),
        lte(partnerTransactions.transactionDate, endDate)
      )
    )
    .groupBy(partnerTransactions.partnerId);
}

export async function getTotalRevenueWithPartners(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return { internalRevenue: 0, partnerRevenue: 0, totalRevenue: 0 };
  
  // Internal bookings revenue
  const internalResult = await db
    .select({ total: sql<number>`SUM(${bookings.fare})` })
    .from(bookings)
    .where(
      and(
        eq(bookings.bookingSource, "internal"),
        gte(bookings.pickupDateTime, startDate),
        lte(bookings.pickupDateTime, endDate)
      )
    );
  
  // Partner revenue
  const partnerResult = await db
    .select({ total: sql<number>`SUM(${partnerTransactions.netAmount})` })
    .from(partnerTransactions)
    .where(
      and(
        gte(partnerTransactions.transactionDate, startDate),
        lte(partnerTransactions.transactionDate, endDate)
      )
    );
  
  const internalRevenue = internalResult[0]?.total || 0;
  const partnerRevenue = partnerResult[0]?.total || 0;
  
  return {
    internalRevenue,
    partnerRevenue,
    totalRevenue: internalRevenue + partnerRevenue,
  };
}


// ============================================================================
// CLIENTS (العملاء) - Helper Functions
// ============================================================================

export async function createClient(data: InsertClient): Promise<Client | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create client: database not available");
    return null;
  }

  try {
    await db.insert(clients).values(data);
    
    // Get the last inserted client
    const result = await db.select().from(clients).orderBy(desc(clients.createdAt)).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to create client:", error);
    throw error;
  }
}

export async function getClients(): Promise<Client[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get clients: database not available");
    return [];
  }

  try {
    return await db.select().from(clients).orderBy(desc(clients.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get clients:", error);
    return [];
  }
}

export async function getClientById(id: number): Promise<Client | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get client: database not available");
    return null;
  }

  try {
    const result = await db.select().from(clients).where(eq(clients.id, id));
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get client:", error);
    return null;
  }
}

export async function updateClient(id: number, data: Partial<InsertClient>): Promise<Client | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update client: database not available");
    return null;
  }

  try {
    await db.update(clients).set(data).where(eq(clients.id, id));
    return await getClientById(id);
  } catch (error) {
    console.error("[Database] Failed to update client:", error);
    throw error;
  }
}

export async function deleteClient(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete client: database not available");
    return false;
  }

  try {
    await db.delete(clients).where(eq(clients.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete client:", error);
    return false;
  }
}

// ============================================================================
// RECEIVABLES (الذمم) - Helper Functions
// ============================================================================

export async function createReceivable(data: InsertReceivable): Promise<Receivable | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create receivable: database not available");
    return null;
  }

  try {
    await db.insert(receivables).values(data);
    
    // Get the last inserted receivable
    const result = await db.select().from(receivables).orderBy(desc(receivables.createdAt)).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to create receivable:", error);
    throw error;
  }
}

export async function getReceivables(): Promise<any[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get receivables: database not available");
    return [];
  }

  try {
    return await db
      .select({
        id: receivables.id,
        clientId: receivables.clientId,
        bookingId: receivables.bookingId,
        bookingNumber: bookings.bookingNumber,
        amount: receivables.amount,
        remainingAmount: receivables.remainingAmount,
        status: receivables.status,
        dueDate: receivables.dueDate,
        createdAt: receivables.createdAt,
        notes: receivables.notes,
      })
      .from(receivables)
      .leftJoin(bookings, eq(receivables.bookingId, bookings.id))
      .orderBy(desc(receivables.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get receivables:", error);
    return [];
  }
}

export async function getReceivablesByClientId(clientId: number): Promise<Receivable[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get receivables: database not available");
    return [];
  }

  try {
    return await db.select().from(receivables).where(eq(receivables.clientId, clientId));
  } catch (error) {
    console.error("[Database] Failed to get receivables by client:", error);
    return [];
  }
}

export async function getReceivableById(id: number): Promise<Receivable | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get receivable: database not available");
    return null;
  }

  try {
    const result = await db.select().from(receivables).where(eq(receivables.id, id));
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get receivable:", error);
    return null;
  }
}

export async function updateReceivable(id: number, data: Partial<InsertReceivable>): Promise<Receivable | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update receivable: database not available");
    return null;
  }

  try {
    const updateData: any = {};
    
    if (data.remainingAmount !== undefined) {
      updateData.remainingAmount = typeof data.remainingAmount === 'string' ? parseFloat(data.remainingAmount) : data.remainingAmount;
    }
    if (data.status !== undefined) {
      updateData.status = data.status;
    }
    if (data.dueDate !== undefined) {
      updateData.dueDate = data.dueDate;
    }
    if (data.notes !== undefined) {
      updateData.notes = data.notes;
    }
    
    console.log("[Database] Updating receivable:", id, updateData);
    
    const result = await db.update(receivables).set(updateData).where(eq(receivables.id, id));
    
    console.log("[Database] Update result:", result);
    
    return await getReceivableById(id);
  } catch (error) {
    console.error("[Database] Failed to update receivable:", error);
    throw error;
  }
}

export async function getReceivablesWithCustomers(): Promise<any[]> {
  const db = await getDb();
  if (!db) return [];
  
  try {
    return await db
      .select({
        id: receivables.id,
        clientId: receivables.clientId,
        clientName: clients.name,
        clientPhone: clients.phone,
        clientEmail: clients.email,
        bookingId: receivables.bookingId,
        bookingNumber: bookings.bookingNumber,
        amount: receivables.amount,
        remainingAmount: receivables.remainingAmount,
        status: receivables.status,
        dueDate: receivables.dueDate,
        createdAt: receivables.createdAt,
        notes: receivables.notes,
      })
      .from(receivables)
      .leftJoin(clients, eq(receivables.clientId, clients.id))
      .leftJoin(bookings, eq(receivables.bookingId, bookings.id))
      .orderBy(desc(receivables.dueDate));
  } catch (error) {
    console.error("[Database] Failed to get receivables with customers:", error);
    return [];
  }
}

export async function getReceivablesStats(): Promise<any> {
  const db = await getDb();
  if (!db) return { total: 0, pending: 0, partial: 0, paid: 0 };
  
  try {
    const result = await db
      .select({
        status: receivables.status,
        count: sql<number>`COUNT(*)`,
        totalAmount: sql<number>`SUM(${receivables.amount})`,
        remainingAmount: sql<number>`SUM(${receivables.remainingAmount})`,
      })
      .from(receivables)
      .groupBy(receivables.status);
    
    console.log('[getReceivablesStats] Raw result:', result);
    
    const stats = {
      total: 0,
      pending: 0,
      partial: 0,
      paid: 0,
      totalAmount: 0,
      remainingAmount: 0,
    };
    
    result.forEach((row: any) => {
      const count = Number(row.count) || 0;
      const totalAmount = Number(row.totalAmount) || 0;
      const remainingAmount = Number(row.remainingAmount) || 0;
      
      stats.total += count;
      stats.totalAmount += totalAmount;
      
      if (row.status === 'pending' || row.status === 'partial') {
        stats.remainingAmount += remainingAmount;
      }
      
      if (row.status === 'pending') stats.pending = count;
      else if (row.status === 'partial') stats.partial = count;
      else if (row.status === 'paid') stats.paid = count;
    });
    
    console.log('[getReceivablesStats] Final stats:', stats);
    return stats;
  } catch (error) {
    console.error("[Database] Failed to get receivables stats:", error);
    return { total: 0, pending: 0, partial: 0, paid: 0 };
  }
}

// ============================================================================
// PAYMENTS (الدفعات) - Helper Functions
// ============================================================================

export async function createPayment(data: InsertPayment): Promise<Payment | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create payment: database not available");
    return null;
  }

  try {
    // إدراج الدفعة
    await db.insert(payments).values(data);
    
    // تحديث جدول receivables بالمبلغ المدفوع
    if (data.receivableId) {
      const receivable = await db.select().from(receivables).where(eq(receivables.id, data.receivableId)).limit(1);
      if (receivable.length > 0) {
        const r = receivable[0];
        const newPaidAmount = (Number(r.paidAmount) || 0) + Number(data.amount);
        const newRemainingAmount = Math.max(0, Number(r.amount) - newPaidAmount);
        
        await db.update(receivables).set({
          paidAmount: newPaidAmount.toString(),
          remainingAmount: newRemainingAmount.toString(),
        }).where(eq(receivables.id, data.receivableId));
      }
    }
    
    // Get the last inserted payment
    const result = await db.select().from(payments).orderBy(desc(payments.createdAt)).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to create payment:", error);
    throw error;
  }
}

export async function getPayments(): Promise<Payment[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get payments: database not available");
    return [];
  }

  try {
    return await db.select().from(payments).orderBy(desc(payments.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get payments:", error);
    return [];
  }
}

export async function getPaymentsByClientId(clientId: number): Promise<Payment[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get payments: database not available");
    return [];
  }

  try {
    return await db.select().from(payments).where(eq(payments.clientId, clientId));
  } catch (error) {
    console.error("[Database] Failed to get payments by client:", error);
    return [];
  }
}

export async function getPaymentsByReceivableId(receivableId: number): Promise<Payment[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get payments: database not available");
    return [];
  }

  try {
    return await db.select().from(payments).where(eq(payments.receivableId, receivableId));
  } catch (error) {
    console.error("[Database] Failed to get payments by receivable:", error);
    return [];
  }
}

export async function getPaymentById(id: number): Promise<Payment | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get payment: database not available");
    return null;
  }

  try {
    const result = await db.select().from(payments).where(eq(payments.id, id));
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get payment:", error);
    return null;
  }
}


// ============================================================================
// INVOICES (الفواتير) - Helper Functions
// ============================================================================

export async function createInvoice(data: InsertInvoice): Promise<Invoice | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create invoice: database not available");
    return null;
  }

  try {
    await db.insert(invoices).values(data);
    
    // Get the last inserted invoice
    const result = await db.select().from(invoices).orderBy(desc(invoices.createdAt)).limit(1);
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to create invoice:", error);
    throw error;
  }
}

export async function getInvoices(): Promise<Invoice[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get invoices: database not available");
    return [];
  }

  try {
    return await db.select().from(invoices).orderBy(desc(invoices.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get invoices:", error);
    return [];
  }
}

export async function getInvoicesByClientId(clientId: number): Promise<Invoice[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get invoices: database not available");
    return [];
  }

  try {
    return await db.select().from(invoices).where(eq(invoices.clientId, clientId));
  } catch (error) {
    console.error("[Database] Failed to get invoices by client:", error);
    return [];
  }
}

export async function getInvoiceById(id: number): Promise<Invoice | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get invoice: database not available");
    return null;
  }

  try {
    const result = await db.select().from(invoices).where(eq(invoices.id, id));
    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get invoice:", error);
    return null;
  }
}

export async function updateInvoice(id: number, data: Partial<InsertInvoice>): Promise<Invoice | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update invoice: database not available");
    return null;
  }

  try {
    await db.update(invoices).set(data).where(eq(invoices.id, id));
    return await getInvoiceById(id);
  } catch (error) {
    console.error("[Database] Failed to update invoice:", error);
    throw error;
  }
}

export async function deleteInvoice(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete invoice: database not available");
    return false;
  }

  try {
    await db.delete(invoices).where(eq(invoices.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete invoice:", error);
    return false;
  }
}

export async function getInvoicesByStatus(status: string): Promise<Invoice[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get invoices: database not available");
    return [];
  }

  try {
    return await db.select().from(invoices).where(eq(invoices.status, status as any));
  } catch (error) {
    console.error("[Database] Failed to get invoices by status:", error);
    return [];
  }
}


// Delete Receivable
export async function deleteReceivable(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete receivable: database not available");
    return false;
  }

  try {
    await db.delete(receivables).where(eq(receivables.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete receivable:", error);
    return false;
  }
}

// Delete Payment
export async function deletePayment(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete payment: database not available");
    return false;
  }

  try {
    // Get the payment first
    const paymentResult = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
    const paymentToDelete = paymentResult.length > 0 ? paymentResult[0] : null;

    if (paymentToDelete && paymentToDelete.receivableId) {
      // Get the receivable
      const receivableResult = await db.select().from(receivables).where(eq(receivables.id, paymentToDelete.receivableId)).limit(1);
      const receivable = receivableResult.length > 0 ? receivableResult[0] : null;

      if (receivable) {
        // Update remaining amount by adding back the payment amount
        const newRemainingAmount = (Number(receivable.remainingAmount) + Number(paymentToDelete.amount)).toString();
        await db.update(receivables)
          .set({ remainingAmount: newRemainingAmount })
          .where(eq(receivables.id, paymentToDelete.receivableId));
      }
    }

    // Delete the payment
    await db.delete(payments).where(eq(payments.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete payment:", error);
    return false;
  }
}


// ============================================================================
// SMART PAYMENTS (الدفعات الذكية) - Helper Functions
// ============================================================================

/**
 * Process a smart payment that automatically allocates payment to oldest receivables first
 * @param clientId - Client ID
 * @param amount - Payment amount
 * @param paymentMethod - Payment method (cash, card, transfer, check, other)
 * @param referenceNumber - Optional reference number (for checks or transfers)
 * @param notes - Optional notes
 * @returns Array of created payments
 */
export async function processSmartPayment(
  clientId: number,
  amount: number,
  paymentMethod: "cash" | "card" | "transfer" | "check" | "other",
  referenceNumber?: string,
  notes?: string
): Promise<Payment[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot process smart payment: database not available");
    return [];
  }

  try {
    // Get all pending/partial receivables for this client, ordered by creation date (oldest first)
    const clientReceivables = await db
      .select()
      .from(receivables)
      .where(
        and(
          eq(receivables.clientId, clientId),
          sql`status IN ('pending', 'partial')`
        )
      )
      .orderBy(receivables.createdAt);

    const createdPayments: Payment[] = [];
    let remainingAmount = amount;

    // Allocate payment to each receivable starting from the oldest
    for (const receivable of clientReceivables) {
      if (remainingAmount <= 0) break;

      const receivableRemaining = Number(receivable.remainingAmount);
      const paymentForThisReceivable = Math.min(remainingAmount, receivableRemaining);

      // Create payment record
      const paymentData: InsertPayment = {
        receivableId: receivable.id,
        clientId: clientId,
        amount: paymentForThisReceivable.toString() as any,
        paymentMethod,
        referenceNumber: referenceNumber || null,
        notes: notes || null,
        paymentDate: new Date(),
      };

      const payment = await createPayment(paymentData);
      if (payment) {
        createdPayments.push(payment);
      }

      // Update receivable
      const newPaidAmount = Number(receivable.paidAmount) + paymentForThisReceivable;
      const newRemainingAmount = receivableRemaining - paymentForThisReceivable;
      const newStatus =
        newRemainingAmount <= 0
          ? "paid"
          : newPaidAmount > 0
            ? "partial"
            : "pending";

      await updateReceivable(receivable.id, {
        paidAmount: newPaidAmount as any,
        remainingAmount: Math.max(0, newRemainingAmount) as any,
        status: newStatus as any,
      });

      remainingAmount -= paymentForThisReceivable;
    }

    return createdPayments;
  } catch (error) {
    console.error("[Database] Failed to process smart payment:", error);
    throw error;
  }
}

/**
 * Get pending/partial receivables for a client (oldest first)
 */
export async function getPendingReceivablesByClientId(clientId: number): Promise<Receivable[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get pending receivables: database not available");
    return [];
  }

  try {
    return await db
      .select()
      .from(receivables)
      .where(
        and(
          eq(receivables.clientId, clientId),
          sql`status IN ('pending', 'partial', 'paid')`
        )
      )
      .orderBy(receivables.createdAt);
  } catch (error) {
    console.error("[Database] Failed to get pending receivables:", error);
    return [];
  }
}

// ============================================================================
// CLIENT ACCOUNT STATEMENT (حركة حساب العميل) - Helper Functions
// ============================================================================

export interface ClientAccountTransaction {
  id: string;
  type: "booking" | "payment" | "expense";
  description: string;
  amount: number;
  date: Date;
  status: string;
  reference?: string;
}

export async function getClientAccountStatement(
  clientId: number,
  startDate?: Date,
  endDate?: Date
): Promise<ClientAccountTransaction[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get client account statement: database not available");
    return [];
  }

  try {
    const transactions: ClientAccountTransaction[] = [];

    // 1. Get bookings (income)
    const bookingQuery = db
      .select({
        id: bookings.id,
        bookingNumber: bookings.bookingNumber,
        fare: bookings.fare,
        pickupDateTime: bookings.pickupDateTime,
        status: bookings.status,
      })
      .from(bookings)
      .where(eq(bookings.clientId, clientId));

    const bookingResults = await bookingQuery;
    
    bookingResults.forEach((booking: any) => {
      const bookingDate = new Date(booking.pickupDateTime);
      if ((!startDate || bookingDate >= startDate) && (!endDate || bookingDate <= endDate)) {
        transactions.push({
          id: `booking-${booking.id}`,
          type: "booking",
          description: `حجز #${booking.bookingNumber}`,
          amount: Number(booking.fare),
          date: bookingDate,
          status: booking.status,
          reference: booking.bookingNumber,
        });
      }
    });

    // 2. Get payments (سدادات)
    const paymentQuery = db
      .select({
        id: payments.id,
        amount: payments.amount,
        paymentDate: payments.paymentDate,
        paymentMethod: payments.paymentMethod,
        referenceNumber: payments.referenceNumber,
      })
      .from(payments)
      .where(eq(payments.clientId, clientId));

    const paymentResults = await paymentQuery;
    
    paymentResults.forEach((payment: any) => {
      const paymentDate = new Date(payment.paymentDate);
      if ((!startDate || paymentDate >= startDate) && (!endDate || paymentDate <= endDate)) {
        transactions.push({
          id: `payment-${payment.id}`,
          type: "payment",
          description: `سداد - ${payment.paymentMethod}`,
          amount: -Number(payment.amount), // Negative for payments
          date: paymentDate,
          status: "paid",
          reference: payment.referenceNumber,
        });
      }
    });

    // 3. Expenses are NOT included in client account statement
    // All expenses are managed centrally in the Finances page only

    // Sort by date (newest first)
    transactions.sort((a, b) => b.date.getTime() - a.date.getTime());

    return transactions;
  } catch (error) {
    console.error("[Database] Failed to get client account statement:", error);
    return [];
  }
}

export async function getClientAccountBalance(clientId: number): Promise<{
  totalIncome: number;
  totalPayments: number;
  totalExpenses: number;
  balance: number;
}> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get client balance: database not available");
    return { totalIncome: 0, totalPayments: 0, totalExpenses: 0, balance: 0 };
  }

  try {
    // Get total bookings (income)
    const bookingResult = await db
      .select({ total: sql<number>`COALESCE(SUM(${bookings.fare}), 0)` })
      .from(bookings)
      .where(eq(bookings.clientId, clientId));
    
    const totalIncome = Number(bookingResult[0]?.total || 0);

    // Get total payments
    const paymentResult = await db
      .select({ total: sql<number>`COALESCE(SUM(${payments.amount}), 0)` })
      .from(payments)
      .where(eq(payments.clientId, clientId));
    
    const totalPayments = Number(paymentResult[0]?.total || 0);

    // Get total expenses (if any)
    const expenseResult = await db
      .select({ total: sql<number>`COALESCE(SUM(${transactionsV2.amount}), 0)` })
      .from(transactionsV2)
      .where(eq(transactionsV2.transactionType, "expense"));
    
    const totalExpenses = Number(expenseResult[0]?.total || 0);

    const balance = totalIncome - totalPayments - totalExpenses;

    return {
      totalIncome,
      totalPayments,
      totalExpenses,
      balance,
    };
  } catch (error) {
    console.error("[Database] Failed to get client balance:", error);
    return { totalIncome: 0, totalPayments: 0, totalExpenses: 0, balance: 0 };
  }
}

// Overdue Receivables Functions
export async function getOverdueReceivables(daysOverdue: number = 0) {
  try {
    const db = await getDb();
    if (!db) return [];

    const today = new Date();
    const overdueDate = new Date(today);
    overdueDate.setDate(overdueDate.getDate() - daysOverdue);

    const result = await db
      .select({
        id: receivables.id,
        clientId: receivables.clientId,
        customerName: clients.name,
        customerPhone: clients.phone,
        customerEmail: clients.email,
        bookingId: receivables.bookingId,
        amount: receivables.amount,
        remainingAmount: receivables.remainingAmount,
        dueDate: receivables.dueDate,
        status: receivables.status,
        notes: receivables.notes,
        createdAt: receivables.createdAt,
        daysOverdue: sql<number>`CAST(DATEDIFF(CURDATE(), ${receivables.dueDate}) AS SIGNED)`,
      })
      .from(receivables)
      .leftJoin(clients, eq(receivables.clientId, clients.id))
      .where(
        and(
          lt(receivables.dueDate, overdueDate),
          eq(receivables.status, "pending")
        )
      )
      .orderBy(desc(sql<number>`DATEDIFF(CURDATE(), ${receivables.dueDate})`))

    return result;
  } catch (error) {
    console.error("[Database] Failed to get overdue receivables:", error);
    return [];
  }
}

export async function getOverdueStats() {
  try {
    const db = await getDb();
    if (!db) return { totalOverdue: 0, count: 0, averageOverdue: 0 };

    const result = await db
      .select({
        totalOverdue: sql<number>`COALESCE(SUM(${receivables.remainingAmount}), 0)`,
        count: sql<number>`COUNT(${receivables.id})`,
        averageOverdue: sql<number>`COALESCE(AVG(DATEDIFF(CURDATE(), ${receivables.dueDate})), 0)`,
      })
      .from(receivables)
      .where(
        and(
          lt(receivables.dueDate, new Date()),
          eq(receivables.status, "pending")
        )
      );

    const stats = result[0];
    return {
      totalOverdue: Number(stats.totalOverdue) || 0,
      count: Number(stats.count) || 0,
      averageOverdue: Math.round(Number(stats.averageOverdue) || 0),
    };
  } catch (error) {
    console.error("[Database] Failed to get overdue stats:", error);
    return { totalOverdue: 0, count: 0, averageOverdue: 0 };
  }
}

export async function getOverdueReceivablesByCustomer(customerId: string) {
  try {
    const db = await getDb();
    if (!db) return [];

    const result = await db
      .select({
        id: receivables.id,
        clientId: receivables.clientId,
        customerName: clients.name,
        amount: receivables.amount,
        remainingAmount: receivables.remainingAmount,
        dueDate: receivables.dueDate,
        status: receivables.status,
        daysOverdue: sql<number>`CAST(DATEDIFF(CURDATE(), ${receivables.dueDate}) AS SIGNED)`,
      })
      .from(receivables)
      .leftJoin(clients, eq(receivables.clientId, clients.id))
      .where(
        and(
          eq(receivables.clientId, parseInt(customerId)),
          lt(receivables.dueDate, new Date()),
          eq(receivables.status, "pending")
        )
      )
      .orderBy(desc(receivables.dueDate));

    return result;
  } catch (error) {
    console.error("[Database] Failed to get overdue receivables by customer:", error);
    return [];
  }
}


/**
 * Get the latest vehicle location for tracking
 */
export async function getLatestVehicleLocation(vehicleId: number) {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db
      .select()
      .from(vehicleLocations)
      .where(eq(vehicleLocations.vehicleId, vehicleId))
      .orderBy(desc(vehicleLocations.timestamp))
      .limit(1);

    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get latest vehicle location:", error);
    return null;
  }
}
