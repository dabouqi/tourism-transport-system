// This file contains the new routers for clients, receivables, and payments
// These should be added to the appRouter in routers.ts

import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";

export const clientsRouter = router({
  list: protectedProcedure.query(() => db.getClients()),
  
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getClientById(input.id)),
  
  create: protectedProcedure
    .input(z.object({
      name: z.string().min(1),
      type: z.enum(["individual", "company"]),
      email: z.string().email().or(z.literal("")).optional(),
      phone: z.string().optional(),
      address: z.string().optional(),
      taxId: z.string().optional(),
      contactPerson: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => db.createClient(input)),
  
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      type: z.enum(["individual", "company"]).optional(),
      email: z.string().email().or(z.literal("")).optional(),
      phone: z.string().optional(),
      address: z.string().optional(),
      taxId: z.string().optional(),
      contactPerson: z.string().optional(),
      status: z.enum(["active", "inactive", "suspended"]).optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateClient(id, data);
    }),
  
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(({ input }) => db.deleteClient(input.id)),
  
  // ============ CLIENT ACCOUNT STATEMENT ============
  getAccountStatement: protectedProcedure
    .input(z.object({
      clientId: z.number(),
      startDate: z.date().optional(),
      endDate: z.date().optional(),
    }))
    .query(({ input }) => 
      db.getClientAccountStatement(input.clientId, input.startDate, input.endDate)
    ),
  
  getAccountBalance: protectedProcedure
    .input(z.object({ clientId: z.number() }))
    .query(({ input }) => db.getClientAccountBalance(input.clientId)),
});

export const receivablesRouter = router({
  list: protectedProcedure.query(() => db.getReceivables()),
  
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getReceivableById(input.id)),
  
  getByClientId: protectedProcedure
    .input(z.object({ clientId: z.number() }))
    .query(({ input }) => db.getReceivablesByClientId(input.clientId)),
  
  create: protectedProcedure
    .input(z.object({
      clientId: z.number(),
      bookingId: z.number(),
      amount: z.string().or(z.number()),
      dueDate: z.date().optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => db.createReceivable({
      ...input,
      amount: String(input.amount),
      remainingAmount: String(input.amount),
    })),
  
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      amount: z.string().optional(),
      remainingAmount: z.string().optional(),
      dueDate: z.date().optional(),
      status: z.enum(["pending", "partial", "paid", "overdue", "cancelled"]).optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateReceivable(id, data);
    }),
  
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(({ input }) => db.deleteReceivable(input.id)),
  
  getAllWithCustomers: protectedProcedure.query(() => db.getReceivablesWithCustomers()),
  
  getStats: protectedProcedure.query(() => db.getReceivablesStats()),
  
  getOverdue: protectedProcedure
    .input(z.object({ daysOverdue: z.number().optional() }))
    .query(({ input }) => db.getOverdueReceivables(input.daysOverdue)),
  
  getOverdueStats: protectedProcedure.query(() => db.getOverdueStats()),
  
  getOverdueByCustomer: protectedProcedure
    .input(z.object({ customerId: z.string() }))
    .query(({ input }) => db.getOverdueReceivablesByCustomer(input.customerId)),
});

export const paymentsRouter = router({
  list: protectedProcedure.query(() => db.getPayments()),
  
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getPaymentById(input.id)),
  
  getByClientId: protectedProcedure
    .input(z.object({ clientId: z.number() }))
    .query(({ input }) => db.getPaymentsByClientId(input.clientId)),
  
  getByReceivableId: protectedProcedure
    .input(z.object({ receivableId: z.number() }))
    .query(({ input }) => db.getPaymentsByReceivableId(input.receivableId)),
  
  create: protectedProcedure
    .input(z.object({
      receivableId: z.number(),
      clientId: z.number(),
      amount: z.string().or(z.number()),
      paymentMethod: z.enum(["cash", "card", "transfer", "check", "other"]),
      referenceNumber: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => db.createPayment({
      ...input,
      amount: String(input.amount),
      paymentDate: new Date(),
    })),
  
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(({ input }) => db.deletePayment(input.id)),
  
  smartPayment: protectedProcedure
    .input(z.object({
      clientId: z.number(),
      amount: z.string().or(z.number()),
      paymentMethod: z.enum(["cash", "card", "transfer", "check", "other"]),
      referenceNumber: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => db.processSmartPayment(
      input.clientId,
      Number(input.amount),
      input.paymentMethod,
      input.referenceNumber,
      input.notes
    )),
  
  getPendingByClientId: protectedProcedure
    .input(z.object({ clientId: z.number() }))
    .query(({ input }) => db.getPendingReceivablesByClientId(input.clientId)),
});
