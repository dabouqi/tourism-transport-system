import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Printer, Download } from "lucide-react";
import { formatCurrency } from "@/lib/formatters";
import { formatDate } from "@/lib/dateFormatter";
import { toast } from "sonner";

export default function ClientAccountStatement() {
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");

  const clients = trpc.clients.list.useQuery();
  const accountStatement = trpc.clients.getAccountStatement.useQuery(
    {
      clientId: selectedClientId || 0,
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
    },
    { enabled: !!selectedClientId }
  );

  const accountBalance = trpc.clients.getAccountBalance.useQuery(
    { clientId: selectedClientId || 0 },
    { enabled: !!selectedClientId }
  );

  const selectedClient = useMemo(() => {
    if (!selectedClientId || !clients.data) return null;
    return clients.data.find((c: any) => c.id === selectedClientId);
  }, [selectedClientId, clients.data]);

  const handlePrint = () => {
    window.print();
  };

  const handleExport = () => {
    if (!accountStatement.data || !selectedClient) {
      toast.error("لا توجد بيانات للتصدير");
      return;
    }

    // Create CSV content
    let csv = "حركة حساب العميل\n";
    csv += `اسم العميل: ${selectedClient.name}\n`;
    csv += `البريد الإلكتروني: ${selectedClient.email || "-"}\n`;
    csv += `الهاتف: ${selectedClient.phone || "-"}\n`;
    csv += `التاريخ: ${new Date().toLocaleDateString("ar-SA")}\n\n`;

    csv += "التاريخ,النوع,الوصف,المبلغ,الحالة\n";
    accountStatement.data.forEach((transaction: any) => {
      csv += `${formatDate(transaction.date)},${transaction.type},${transaction.description},${transaction.amount},${transaction.status}\n`;
    });

    csv += "\n\nملخص الحساب\n";
    csv += `إجمالي الدخل,${accountBalance.data?.totalIncome || 0}\n`;
    csv += `إجمالي الدفعات,${accountBalance.data?.totalPayments || 0}\n`;
    csv += `إجمالي المصاريف,${accountBalance.data?.totalExpenses || 0}\n`;
    csv += `الرصيد الإجمالي,${accountBalance.data?.balance || 0}\n`;

    // Download CSV
    const element = document.createElement("a");
    element.setAttribute("href", "data:text/csv;charset=utf-8," + encodeURIComponent(csv));
    element.setAttribute("download", `account-statement-${selectedClient.name}.csv`);
    element.style.display = "none";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);

    toast.success("تم تصدير البيانات بنجاح");
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">حركة حساب العميل</h1>
        <div className="flex gap-2">
          <Button onClick={handlePrint} variant="outline" size="sm">
            <Printer className="h-4 w-4 mr-2" />
            طباعة
          </Button>
          <Button onClick={handleExport} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            تصدير
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>الفلاتر</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Client Selection */}
            <div>
              <Label>اختر العميل</Label>
              <Select
                value={selectedClientId?.toString() || ""}
                onValueChange={(value) => setSelectedClientId(Number(value))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر عميل..." />
                </SelectTrigger>
                <SelectContent>
                  {clients.data?.map((client: any) => (
                    <SelectItem key={client.id} value={client.id.toString()}>
                      {client.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Start Date */}
            <div>
              <Label>من التاريخ</Label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>

            {/* End Date */}
            <div>
              <Label>إلى التاريخ</Label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Client Info */}
      {selectedClient && (
        <Card>
          <CardHeader>
            <CardTitle>معلومات العميل</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">اسم العميل</p>
                <p className="font-semibold">{selectedClient.name}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">النوع</p>
                <p className="font-semibold">
                  {selectedClient.type === "individual" ? "فرد" : "شركة"}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">البريد الإلكتروني</p>
                <p className="font-semibold">{selectedClient.email || "-"}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">الهاتف</p>
                <p className="font-semibold">{selectedClient.phone || "-"}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Account Balance Summary */}
      {selectedClient && accountBalance.data && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-500">إجمالي الدخل</p>
                <p className="text-2xl font-bold text-green-600">
                  {formatCurrency(accountBalance.data.totalIncome)}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-500">إجمالي الدفعات</p>
                <p className="text-2xl font-bold text-blue-600">
                  {formatCurrency(accountBalance.data.totalPayments)}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-500">إجمالي المصاريف</p>
                <p className="text-2xl font-bold text-red-600">
                  {formatCurrency(accountBalance.data.totalExpenses)}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-gray-500">الرصيد الإجمالي</p>
                <p
                  className={`text-2xl font-bold ${
                    accountBalance.data.balance >= 0
                      ? "text-green-600"
                      : "text-red-600"
                  }`}
                >
                  {formatCurrency(accountBalance.data.balance)}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Transactions Table */}
      {selectedClient && (
        <Card>
          <CardHeader>
            <CardTitle>حركات الحساب</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead>الوصف</TableHead>
                    <TableHead>المبلغ</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>المرجع</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {accountStatement.isLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        جاري التحميل...
                      </TableCell>
                    </TableRow>
                  ) : accountStatement.data && accountStatement.data.length > 0 ? (
                    accountStatement.data.map((transaction: any) => (
                      <TableRow key={transaction.id}>
                        <TableCell>{formatDate(transaction.date)}</TableCell>
                        <TableCell>
                          <span
                            className={`px-3 py-1 rounded-full text-sm font-medium ${
                              transaction.type === "booking"
                                ? "bg-green-100 text-green-800"
                                : transaction.type === "payment"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {transaction.type === "booking"
                              ? "حجز"
                              : transaction.type === "payment"
                              ? "سداد"
                              : "مصروف"}
                          </span>
                        </TableCell>
                        <TableCell>{transaction.description}</TableCell>
                        <TableCell
                          className={
                            transaction.amount >= 0
                              ? "text-green-600 font-semibold"
                              : "text-red-600 font-semibold"
                          }
                        >
                          {formatCurrency(transaction.amount)}
                        </TableCell>
                        <TableCell>
                          <span
                            className={`px-3 py-1 rounded-full text-sm ${
                              transaction.status === "paid"
                                ? "bg-green-100 text-green-800"
                                : transaction.status === "pending"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {transaction.status === "paid"
                              ? "مدفوع"
                              : transaction.status === "pending"
                              ? "قيد الانتظار"
                              : transaction.status}
                          </span>
                        </TableCell>
                        <TableCell>{transaction.reference || "-"}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8">
                        لا توجد حركات لهذا العميل
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {!selectedClient && (
        <Card>
          <CardContent className="pt-6 text-center">
            <p className="text-gray-500">اختر عميلاً لعرض حركة حسابه</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
