import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, CreditCard, Edit2, Trash2 } from "lucide-react";
import { formatCurrency } from "@/lib/formatters";
import { formatDate, formatDateTime } from "@/lib/dateFormatter";

export default function Receivables() {
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isEditReceivableOpen, setIsEditReceivableOpen] = useState(false);
  const [selectedReceivableId, setSelectedReceivableId] = useState<number | null>(null);
  const [paymentData, setPaymentData] = useState({
    amount: "",
    paymentMethod: "cash" as "cash" | "card" | "transfer" | "check" | "other",
    referenceNumber: "",
    notes: "",
  });

  const [editReceivableData, setEditReceivableData] = useState({
    amount: "",
    dueDate: "",
    status: "pending" as "pending" | "partial" | "paid" | "overdue" | "cancelled",
  });

  const [smartPaymentData, setSmartPaymentData] = useState({
    clientId: undefined as number | undefined,
    bookingNumber: "",
    amount: "",
    paymentMethod: "cash" as "cash" | "card" | "transfer" | "check" | "other",
    referenceNumber: "",
    notes: "",
  });

  const bookingsQuery = trpc.bookings.list.useQuery();

  const receivablesQuery = trpc.receivables.list.useQuery();
  const paymentsQuery = trpc.payments.list.useQuery();
  const clientsQuery = trpc.clients.list.useQuery();
  const pendingReceivablesQuery = trpc.payments.getPendingByClientId.useQuery(
    { clientId: smartPaymentData.clientId || 0 },
    { enabled: (smartPaymentData.clientId || 0) > 0 }
  );
  const createPaymentMutation = trpc.payments.create.useMutation();
  const updateReceivableMutation = trpc.receivables.update.useMutation();
  const deleteReceivableMutation = trpc.receivables.delete.useMutation();
  const deletePaymentMutation = trpc.payments.delete.useMutation();
  const smartPaymentMutation = trpc.payments.smartPayment.useMutation();

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedReceivableId) return;

    try {
      const receivable = receivablesQuery.data?.find((r: any) => r.id === selectedReceivableId);
      if (!receivable) return;

      // تحويل المبلغ من string إلى number
      const amountNumber = parseFloat(paymentData.amount);
      if (isNaN(amountNumber) || amountNumber <= 0) {
        toast.error("يجب إدخال مبلغ صحيح");
        return;
      }

      await createPaymentMutation.mutateAsync({
        receivableId: selectedReceivableId,
        clientId: receivable.clientId,
        amount: amountNumber,
        paymentMethod: paymentData.paymentMethod,
        referenceNumber: paymentData.referenceNumber,
        notes: paymentData.notes,
      });

      // Update receivable status
      const remainingAmount = parseFloat(receivable.remainingAmount) - parseFloat(paymentData.amount);
      const newStatus = remainingAmount <= 0 ? "paid" : remainingAmount < parseFloat(receivable.amount) ? "partial" : "pending";

      await updateReceivableMutation.mutateAsync({
        id: selectedReceivableId,
        status: newStatus,
      });

      toast.success("تم تسجيل الدفعة بنجاح");
      setPaymentData({
        amount: "",
        paymentMethod: "cash",
        referenceNumber: "",
        notes: "",
      });
      setSelectedReceivableId(null);
      setIsPaymentOpen(false);
      // invalidate سيتم استدعاؤه تلقائياً من Bookings.tsx عند تحديث الحجز
      // لا نحتاج إلى refetch هنا
    } catch (error) {
      toast.error("حدث خطأ أثناء تسجيل الدفعة");
    }
  };

  const handleEditReceivable = (receivable: any) => {
    setEditReceivableData({
      amount: receivable.remainingAmount,
      dueDate: receivable.dueDate ? new Date(receivable.dueDate).toISOString().split('T')[0] : "",
      status: receivable.status,
    });
    setSelectedReceivableId(receivable.id);
    setIsEditReceivableOpen(true);
  };

  const handleUpdateReceivable = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReceivableId) return;

    try {
      await updateReceivableMutation.mutateAsync({
        id: selectedReceivableId,
        remainingAmount: editReceivableData.amount,
        dueDate: editReceivableData.dueDate ? new Date(editReceivableData.dueDate) : undefined,
        status: editReceivableData.status,
      });

      toast.success("تم تحديث الذمة بنجاح");
      setIsEditReceivableOpen(false);
      setSelectedReceivableId(null);
      // invalidate سيتم استدعاؤه تلقائياً
    } catch (error) {
      toast.error("حدث خطأ أثناء تحديث الذمة");
    }
  };

  const handleDeleteReceivable = (id: number) => {
    if (window.confirm("هل أنت متأكد من حذف هذه الذمة؟")) {
      deleteReceivableMutation.mutate(
        { id },
        {
          onSuccess: () => {
            toast.success("تم حذف الذمة بنجاح");
            receivablesQuery.refetch();
          },
          onError: () => {
            toast.error("حدث خطأ أثناء حذف الذمة");
          },
        }
      );
    }
  };

  const handleDeletePayment = (id: number) => {
    if (window.confirm("هل أنت متأكد من حذف هذه الدفعة؟")) {
      deletePaymentMutation.mutate(
        { id },
        {
          onSuccess: () => {
            toast.success("تم حذف الدفعة بنجاح");
            paymentsQuery.refetch();
            receivablesQuery.refetch();
          },
          onError: () => {
            toast.error("حدث خطأ أثناء حذف الدفعة");
          },
        }
      );
    }
  };

  const handleSmartPaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if ((!smartPaymentData.clientId && !smartPaymentData.bookingNumber) || !smartPaymentData.amount || smartPaymentData.amount === "0") {
      toast.error("الرجاء ملء رقم الحجز أو اسم العميل والمبلغ");
      return;
    }

    try {
      const amountNumber = parseFloat(smartPaymentData.amount);
      if (isNaN(amountNumber) || amountNumber <= 0) {
        toast.error("يجب إدخال مبلغ صحيح");
        return;
      }

      await smartPaymentMutation.mutateAsync({
        clientId: smartPaymentData.clientId || undefined,
        bookingNumber: smartPaymentData.bookingNumber || undefined,
        amount: amountNumber,
        paymentMethod: smartPaymentData.paymentMethod,
        referenceNumber: smartPaymentData.referenceNumber || undefined,
        notes: smartPaymentData.notes || undefined,
      } as any);

      toast.success("تم تسجيل الدفعة بنجاح");
      setSmartPaymentData({
        clientId: undefined,
        bookingNumber: "",
        amount: "",
        paymentMethod: "cash",
        referenceNumber: "",
        notes: "",
      });
      // invalidate سيتم استدعاؤه تلقائياً من Bookings.tsx عند تحديث الحجز
      // لا نحتاج إلى refetch هنا
      pendingReceivablesQuery.refetch();
    } catch (error) {
      toast.error("حدث خطأ أثناء تسجيل الدفعة");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "partial":
        return "bg-blue-100 text-blue-800";
      case "paid":
        return "bg-green-100 text-green-800";
      case "overdue":
        return "bg-red-100 text-red-800";
      case "cancelled":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "pending":
        return "مستحقة";
      case "partial":
        return "مدفوعة جزئياً";
      case "paid":
        return "مدفوعة";
      case "overdue":
        return "متأخرة";
      case "cancelled":
        return "ملغاة";
      default:
        return status;
    }
  };

  const getClientName = (clientId: number) => {
    const client = clientsQuery.data?.find((c: any) => c.id === clientId);
    return client?.name || `العميل #${clientId}`;
  };

  const totalReceivables = receivablesQuery.data?.reduce((sum: number, r: any) => sum + parseFloat(r.remainingAmount || 0), 0) || 0;
  const totalPaid = paymentsQuery.data?.reduce((sum: number, p: any) => sum + parseFloat(p.amount || 0), 0) || 0;

  if (receivablesQuery.isLoading) {
    return <div className="p-4">جاري التحميل...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">الذمم والدفعات</h1>
          <p className="text-gray-500 mt-1">إدارة الذمم المستحقة والدفعات</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">إجمالي الذمم</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalReceivables)}</div>
            <p className="text-xs text-gray-500 mt-1">{receivablesQuery.data?.length || 0} ذمة</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">إجمالي الدفعات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalPaid)}</div>
            <p className="text-xs text-gray-500 mt-1">{paymentsQuery.data?.length || 0} دفعة</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">المتبقي</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(totalReceivables - totalPaid)}</div>
            <p className="text-xs text-gray-500 mt-1">المبلغ المتبقي</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="receivables" className="w-full">
        <TabsList>
          <TabsTrigger value="receivables">الذمم المستحقة</TabsTrigger>
          <TabsTrigger value="payments">الدفعات المسجلة</TabsTrigger>
        </TabsList>

        <TabsContent value="receivables">
          <Card>
            <CardHeader>
              <CardTitle>الذمم المستحقة</CardTitle>
              <CardDescription>جميع الذمم المستحقة على العملاء والشركات</CardDescription>
            </CardHeader>
            <CardContent>
              {receivablesQuery.data && receivablesQuery.data.length === 0 ? (
                <div className="text-center py-8 text-gray-500">لا توجد ذمم مسجلة</div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>العميل</TableHead>
                        <TableHead>الحجز</TableHead>
                        <TableHead>المبلغ الأصلي</TableHead>
                        <TableHead>المبلغ المدفوع</TableHead>
                        <TableHead>المبلغ المتبقي</TableHead>
                        <TableHead>الحالة</TableHead>
                        <TableHead>تاريخ الاستحقاق</TableHead>
                        <TableHead className="text-center">الإجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {receivablesQuery.data?.map((receivable: any) => (
                        <TableRow key={receivable.id}>
                          <TableCell className="font-medium">{getClientName(receivable.clientId)}</TableCell>
                          <TableCell>{receivable.bookingNumber || "-"}</TableCell>
                          <TableCell>{formatCurrency(receivable.amount)}</TableCell>
                          <TableCell className="font-medium text-green-600">
                            {formatCurrency(parseFloat(receivable.amount) - parseFloat(receivable.remainingAmount))}
                          </TableCell>
                          <TableCell className="font-medium text-red-600">
                            {formatCurrency(receivable.remainingAmount)}
                          </TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(receivable.status)}`}>
                              {getStatusLabel(receivable.status)}
                            </span>
                          </TableCell>
                          <TableCell>
                            {receivable.dueDate ? formatDate(receivable.dueDate) : "-"}
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex gap-2">
                              {/* زر الدفعة */}
                              <Dialog open={isPaymentOpen && selectedReceivableId === receivable.id} onOpenChange={setIsPaymentOpen}>
                                <DialogTrigger asChild>
                                  <Button
                                    size="sm"
                                    onClick={() => setSelectedReceivableId(receivable.id)}
                                    disabled={receivable.status === "paid" || receivable.status === "cancelled"}
                                  >
                                    <CreditCard className="w-4 h-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>تسجيل دفعة</DialogTitle>
                                    <DialogDescription>
                                      تسجيل دفعة للذمة رقم {receivable.id} - المبلغ المتبقي: {formatCurrency(receivable.remainingAmount)}
                                    </DialogDescription>
                                  </DialogHeader>
                                  <form onSubmit={handlePaymentSubmit} className="space-y-4">
                                    <div>
                                      <Label htmlFor="amount">المبلغ *</Label>
                                      <Input
                                        id="amount"
                                        type="number"
                                        step="0.01"
                                        value={paymentData.amount}
                                        onChange={(e) => setPaymentData({ ...paymentData, amount: e.target.value })}
                                        placeholder="أدخل المبلغ"
                                        max={receivable.remainingAmount}
                                        required
                                      />
                                    </div>

                                    <div>
                                      <Label htmlFor="paymentMethod">طريقة الدفع *</Label>
                                      <Select
                                        value={paymentData.paymentMethod}
                                        onValueChange={(value: any) => setPaymentData({ ...paymentData, paymentMethod: value })}
                                      >
                                        <SelectTrigger>
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="cash">نقدي</SelectItem>
                                          <SelectItem value="card">بطاقة</SelectItem>
                                          <SelectItem value="transfer">تحويل بنكي</SelectItem>
                                          <SelectItem value="check">شيك</SelectItem>
                                          <SelectItem value="other">أخرى</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>

                                    <div>
                                      <Label htmlFor="referenceNumber">رقم المرجع</Label>
                                      <Input
                                        id="referenceNumber"
                                        value={paymentData.referenceNumber}
                                        onChange={(e) => setPaymentData({ ...paymentData, referenceNumber: e.target.value })}
                                        placeholder="رقم الشيك أو التحويل"
                                      />
                                    </div>

                                    <div>
                                      <Label htmlFor="notes">ملاحظات</Label>
                                      <Input
                                        id="notes"
                                        value={paymentData.notes}
                                        onChange={(e) => setPaymentData({ ...paymentData, notes: e.target.value })}
                                        placeholder="ملاحظات إضافية"
                                      />
                                    </div>

                                    <div className="flex justify-end gap-2">
                                      <Button type="button" variant="outline" onClick={() => setIsPaymentOpen(false)}>
                                        إلغاء
                                      </Button>
                                      <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                                        تسجيل الدفعة
                                      </Button>
                                    </div>
                                  </form>
                                </DialogContent>
                              </Dialog>

                              {/* زر التعديل */}
                              <Dialog open={isEditReceivableOpen && selectedReceivableId === receivable.id} onOpenChange={setIsEditReceivableOpen}>
                                <DialogTrigger asChild>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleEditReceivable(receivable)}
                                  >
                                    <Edit2 className="w-4 h-4" />
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>تعديل الذمة</DialogTitle>
                                  </DialogHeader>
                                  <form onSubmit={handleUpdateReceivable} className="space-y-4">
                                    <div>
                                      <Label htmlFor="edit-amount">المبلغ *</Label>
                                      <Input
                                        id="edit-amount"
                                        type="number"
                                        step="0.01"
                                        value={editReceivableData.amount}
                                        onChange={(e) => setEditReceivableData({ ...editReceivableData, amount: e.target.value })}
                                        required
                                      />
                                    </div>

                                    <div>
                                      <Label htmlFor="edit-dueDate">تاريخ الاستحقاق</Label>
                                      <Input
                                        id="edit-dueDate"
                                        type="date"
                                        value={editReceivableData.dueDate}
                                        onChange={(e) => setEditReceivableData({ ...editReceivableData, dueDate: e.target.value })}
                                      />
                                    </div>

                                    <div>
                                      <Label htmlFor="edit-status">الحالة</Label>
                                      <Select
                                        value={editReceivableData.status}
                                        onValueChange={(value: any) => setEditReceivableData({ ...editReceivableData, status: value })}
                                      >
                                        <SelectTrigger>
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="pending">مستحقة</SelectItem>
                                          <SelectItem value="partial">مدفوعة جزئياً</SelectItem>
                                          <SelectItem value="paid">مدفوعة</SelectItem>
                                          <SelectItem value="overdue">متأخرة</SelectItem>
                                          <SelectItem value="cancelled">ملغاة</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>

                                    <div className="flex justify-end gap-2">
                                      <Button type="button" variant="outline" onClick={() => setIsEditReceivableOpen(false)}>
                                        إلغاء
                                      </Button>
                                      <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                                        حفظ التغييرات
                                      </Button>
                                    </div>
                                  </form>
                                </DialogContent>
                              </Dialog>

                              {/* زر الحذف */}
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-red-600 hover:text-red-700"
                                onClick={() => handleDeleteReceivable(receivable.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <CardTitle>الدفعات المسجلة</CardTitle>
              <CardDescription>جميع الدفعات المسجلة على النظام</CardDescription>
            </CardHeader>
            <CardContent>
              {paymentsQuery.data && paymentsQuery.data.length === 0 ? (
                <div className="text-center py-8 text-gray-500">لا توجد دفعات مسجلة</div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>الذمة</TableHead>
                        <TableHead>المبلغ</TableHead>
                        <TableHead>طريقة الدفع</TableHead>
                        <TableHead>رقم المرجع</TableHead>
                        <TableHead>التاريخ</TableHead>
                        <TableHead>الملاحظات</TableHead>
                        <TableHead>الإجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paymentsQuery.data?.map((payment: any) => (
                        <TableRow key={payment.id}>
                          <TableCell className="font-medium">#{payment.receivableId}</TableCell>
                          <TableCell>{formatCurrency(payment.amount)}</TableCell>
                          <TableCell>
                            {payment.paymentMethod === "cash" && "نقدي"}
                            {payment.paymentMethod === "card" && "بطاقة"}
                            {payment.paymentMethod === "transfer" && "تحويل بنكي"}
                            {payment.paymentMethod === "check" && "شيك"}
                            {payment.paymentMethod === "other" && "أخرى"}
                          </TableCell>
                          <TableCell>{payment.referenceNumber || "-"}</TableCell>
                          <TableCell>
                            {payment.createdAt ? formatDateTime(payment.createdAt) : "-"}
                          </TableCell>
                          <TableCell>{payment.notes || "-"}</TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-600 hover:text-red-700"
                              onClick={() => handleDeletePayment(payment.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* نموذج تسجيل الدفعة السريعة */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>تسجيل دفعة سريعة</CardTitle>
          <CardDescription>اختر العميل والمبلغ وطريقة الدفع</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSmartPaymentSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* اختيار العميل (اختياري) */}
              <div>
                <Label>العميل (اختياري)</Label>
                <Select value={(smartPaymentData.clientId || "").toString()} onValueChange={(value) => setSmartPaymentData({...smartPaymentData, clientId: value !== "" ? parseInt(value) : undefined})}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر العميل" />
                  </SelectTrigger>
                  <SelectContent>
                    {clientsQuery.data?.map((client: any) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* إدخال المبلغ */}
              <div>
                <Label>المبلغ المدفوع *</Label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={smartPaymentData.amount}
                  onChange={(e) => setSmartPaymentData({...smartPaymentData, amount: e.target.value})}
                  required
                />
              </div>

              {/* اختيار طريقة الدفع */}
              <div>
                <Label>طريقة الدفع *</Label>
                <Select value={smartPaymentData.paymentMethod || "cash"} onValueChange={(value) => setSmartPaymentData({...smartPaymentData, paymentMethod: value as any})}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر طريقة الدفع" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">نقد</SelectItem>
                    <SelectItem value="check">شيك</SelectItem>
                    <SelectItem value="transfer">تحويل بنكي</SelectItem>
                    <SelectItem value="card">بطاقة ائتمان</SelectItem>
                    <SelectItem value="other">أخرى</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* رقم المرجع (اختياري) */}
              <div>
                <Label>رقم المرجع (اختياري)</Label>
                <Input
                  type="text"
                  placeholder="رقم الشيك أو التحويل"
                  value={smartPaymentData.referenceNumber}
                  onChange={(e) => setSmartPaymentData({...smartPaymentData, referenceNumber: e.target.value})}
                />
              </div>
            </div>

            {/* ملاحظات */}
            <div>
              <Label>ملاحظات (اختياري)</Label>
              <Input
                type="text"
                placeholder="أضف ملاحظات عن الدفعة"
                value={smartPaymentData.notes}
                onChange={(e) => setSmartPaymentData({...smartPaymentData, notes: e.target.value})}
              />
            </div>

            {/* عرض الذمم المعلقة */}
            {(smartPaymentData.clientId || 0) > 0 && pendingReceivablesQuery.data && pendingReceivablesQuery.data.length > 0 && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm font-semibold text-blue-900 mb-2">الذمم المعلقة للعميل:</p>
                <div className="space-y-1">
                  {pendingReceivablesQuery.data.map((rec: any) => (
                    <p key={rec.id} className="text-sm text-blue-800">
                      • {formatCurrency(rec.remainingAmount)} متبقي (أصلي: {formatCurrency(rec.amount)})
                    </p>
                  ))}
                </div>
              </div>
            )}

            <Button type="submit" className="w-full" disabled={!smartPaymentData.clientId || !smartPaymentData.amount}>
              <CreditCard className="w-4 h-4 ml-2" />
              تسجيل الدفعة
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
