import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit2, Trash2, TrendingUp, TrendingDown, AlertCircle } from "lucide-react";
import { useMemo } from "react";
import { toast } from "sonner";

export default function Finances() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    transactionType: "revenue" as "revenue" | "expense",
    category: "",
    amount: 0,
    description: "",
    transactionDate: new Date().toISOString().split("T")[0],
  });

  const transactions = trpc.transactions.list.useQuery();
  const receivables = trpc.receivables.list.useQuery();
  const createTransaction = trpc.transactions.create.useMutation({
    onSuccess: () => { toast.success("تم تسجيل المعاملة بنجاح"); transactions.refetch(); setIsOpen(false); resetForm(); },
    onError: (error) => { toast.error(error.message || "حدث خطأ أثناء تسجيل المعاملة"); },
  });
  const updateTransaction = trpc.transactions.update.useMutation({
    onSuccess: () => { toast.success("تم تحديث المعاملة بنجاح"); transactions.refetch(); setIsOpen(false); resetForm(); },
    onError: (error) => { toast.error(error.message || "حدث خطأ أثناء تحديث المعاملة"); },
  });
  const bookings = trpc.bookings.list.useQuery();
  const deleteTransaction = trpc.transactions.delete.useMutation({
    onSuccess: () => { 
      toast.success("تم حذف المعاملة بنجاح"); 
      transactions.refetch();
      bookings.refetch(); // تحديث قائمة الحجوزات أيضاً
    },
    onError: (error) => { toast.error(error.message || "حدث خطأ أثناء حذف المعاملة"); },
  });

  const resetForm = () => {
    setFormData({ transactionType: "revenue", category: "", amount: 0, description: "", transactionDate: new Date().toISOString().split("T")[0] });
    setEditingId(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.category || !formData.amount) { toast.error("يرجى ملء جميع الحقول المطلوبة"); return; }
    const transactionData = { transactionType: formData.transactionType as "revenue" | "expense", category: formData.category, amount: parseFloat(formData.amount.toString()), description: formData.description, transactionDate: new Date(formData.transactionDate) };
    if (editingId) { updateTransaction.mutate({ id: editingId, ...transactionData }); } else { createTransaction.mutate(transactionData); }
  };

  const handleEdit = (transaction: any) => {
    setFormData({ transactionType: transaction.transactionType, category: transaction.category, amount: parseFloat(transaction.amount || "0"), description: transaction.description || "", transactionDate: new Date(transaction.transactionDate).toISOString().split("T")[0] });
    setEditingId(transaction.id);
    setIsOpen(true);
  };

  const handleDelete = (id: number) => { if (window.confirm("هل أنت متأكد من حذف هذه المعاملة؟")) { deleteTransaction.mutate({ id }); } };

  const totalRevenue = transactions.data?.filter(t => t.transactionType === "revenue").reduce((sum, t) => sum + (Number(t.amount) || 0), 0) || 0;
  const totalExpense = transactions.data?.filter(t => t.transactionType === "expense").reduce((sum, t) => sum + (Number(t.amount) || 0), 0) || 0;
  const netProfit = totalRevenue - totalExpense;

  const totalReceivables = useMemo(() => {
    if (!receivables.data) return 0;
    return receivables.data
      .filter((r: any) => ['pending', 'partial', 'overdue'].includes(r.status))
      .reduce((sum: number, r: any) => sum + (Number(r.remainingAmount) || 0), 0);
  }, [receivables.data]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">المصاريف والدخل</h1>
          <p className="text-slate-600 mt-1">إدارة المعاملات المالية</p>
        </div>
        <Dialog open={isOpen} onOpenChange={(open) => { setIsOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700 gap-2"><Plus className="w-4 h-4" />معاملة جديدة</Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>{editingId ? "تعديل المعاملة" : "إضافة معاملة جديدة"}</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><Label>نوع المعاملة *</Label><Select value={formData.transactionType} onValueChange={(value) => setFormData({ ...formData, transactionType: value as "revenue" | "expense" })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="revenue">دخل</SelectItem><SelectItem value="expense">مصروف</SelectItem></SelectContent></Select></div>
                <div><Label>الفئة *</Label><Input value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })} placeholder="الحجوزات، الوقود، الصيانة..." /></div>
                <div><Label>المبلغ *</Label><Input type="number" step="0.01" value={formData.amount} onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) })} placeholder="0.00" /></div>
                <div><Label>التاريخ</Label><Input type="date" value={formData.transactionDate} onChange={(e) => setFormData({ ...formData, transactionDate: e.target.value })} /></div>
              </div>
              <div><Label>الوصف</Label><Input value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} placeholder="وصف المعاملة..." /></div>
              <div className="flex gap-2 justify-end">
                <Button type="button" variant="outline" onClick={() => { setIsOpen(false); resetForm(); }}>إلغاء</Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={createTransaction.isPending || updateTransaction.isPending}>{createTransaction.isPending || updateTransaction.isPending ? "جاري المعالجة..." : editingId ? "تحديث المعاملة" : "إضافة المعاملة"}</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">إجمالي الدخل</p>
                <p className="text-2xl font-bold text-green-600">د.ا {totalRevenue.toFixed(2)}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">إجمالي المصروفات</p>
                <p className="text-2xl font-bold text-red-600">د.ا {totalExpense.toFixed(2)}</p>
              </div>
              <TrendingDown className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
        <Card className={`border-0 shadow-sm ${netProfit >= 0 ? "bg-green-50" : "bg-red-50"}`}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600">صافي الربح</p>
                <p className={`text-2xl font-bold ${netProfit >= 0 ? "text-green-600" : "text-red-600"}`}>د.ا {netProfit.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-sm bg-orange-50">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700">إجمالي الذمم المستحقة</p>
                <p className="text-2xl font-bold text-orange-600">د.ا {totalReceivables.toFixed(2)}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-0 shadow-sm">
        <CardHeader><CardTitle>قائمة المعاملات</CardTitle></CardHeader>
        <CardContent>
          {transactions.isLoading ? (<div className="text-center py-8"><p className="text-slate-500">جاري تحميل البيانات...</p></div>) : transactions.data && transactions.data.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-200">
                    <TableHead>التاريخ</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead>الفئة</TableHead>
                    <TableHead>المبلغ</TableHead>
                    <TableHead>الوصف</TableHead>
                    <TableHead className="text-center">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.data?.map((transaction: any) => {
                    const isReadOnly = transaction.isFromBooking;
                    return (
                      <TableRow key={transaction.id} className={`border-slate-200 ${isReadOnly ? "bg-slate-50" : "hover:bg-slate-50"}`}>
                        <TableCell>{new Date(transaction.transactionDate).toLocaleDateString("en-US", { year: "numeric", month: "2-digit", day: "2-digit" })}</TableCell>
                        <TableCell><span className={`px-3 py-1 rounded-full text-xs font-medium ${transaction.transactionType === "revenue" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>{transaction.transactionType === "revenue" ? "دخل" : "مصروف"}</span></TableCell>
                        <TableCell>{transaction.category}</TableCell>
                        <TableCell className={`font-medium ${transaction.transactionType === "revenue" ? "text-green-600" : "text-red-600"}`}>د.ا {parseFloat(transaction.amount || "0").toFixed(2)}</TableCell>
                        <TableCell className="text-sm text-slate-600">{transaction.description || "-"}</TableCell>
                        <TableCell className="text-center">
                          <div className="flex gap-2 justify-center">
                            {!isReadOnly ? (
                              <>
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => handleEdit(transaction)}><Edit2 className="w-4 h-4 text-blue-600" /></Button>
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => handleDelete(transaction.id)} disabled={deleteTransaction.isPending}><Trash2 className="w-4 h-4 text-red-600" /></Button>
                              </>
                            ) : (
                              <span className="text-xs text-slate-500 italic">قراءة فقط</span>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          ) : (<div className="text-center py-8"><p className="text-slate-500">لا توجد معاملات حالياً</p></div>)}
        </CardContent>
      </Card>
    </div>
  );
}
