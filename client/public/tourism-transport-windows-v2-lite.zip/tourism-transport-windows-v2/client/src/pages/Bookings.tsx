"use client";

import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DateRangeSelect } from "@/components/DateRangeSelect";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Edit2, Trash2, Eye, Calendar, TrendingUp, Users, DollarSign, AlertCircle, ChevronDown } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/formatters";
import { formatDateTime, toDatetimeLocal } from "@/lib/dateFormatter";
import { BookingTrackingMap } from "@/components/BookingTrackingMap";

type DateRange = "today" | "week" | "nextWeek" | "month" | "custom" | "all";

export default function BookingsRefactored() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [dateRange, setDateRange] = useState<DateRange>("today");
  const [customStartDate, setCustomStartDate] = useState<string>("");
  const [customEndDate, setCustomEndDate] = useState<string>("");
  const [searchText, setSearchText] = useState("");
  const [bookingTab, setBookingTab] = useState<"all" | "active" | "completed">("active");
  const [showTracking, setShowTracking] = useState(false);
  const [selectedBookingId, setSelectedBookingId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    clientId: undefined as number | undefined,
    bookingNumber: "",
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    pickupLocation: "",
    dropoffLocation: "",
    pickupDateTime: new Date().toISOString().slice(0, 16),
    fare: "0",
    bookingSource: "internal" as "internal" | "talixo" | "get_transfer" | "transfeero",
    status: "pending" as "pending" | "confirmed" | "in_progress" | "completed" | "cancelled",
    notes: "",
    programDays: "",
    programEndDate: "",
  });

  const clients = trpc.clients.list.useQuery();
  const bookings = trpc.bookings.list.useQuery();
  const bookingWithTracking = trpc.bookings.getWithTracking.useQuery(
    { id: selectedBookingId || 0 },
    { enabled: !!selectedBookingId && showTracking }
  );
  const utils = trpc.useUtils();
  
  const createBooking = trpc.bookings.create.useMutation();
  const updateBooking = trpc.bookings.update.useMutation({
    onSuccess: (result) => {
      if (result.priceChanged) {
        utils.bookings.list.invalidate();
        utils.receivables.list.invalidate();
        utils.invoices.getAll.invalidate();
        utils.transactions.list.invalidate();
        utils.dashboard.getTotalReceivables.invalidate();
        utils.dashboard.getStats.invalidate();
      }
    }
  });
  const deleteBooking = trpc.bookings.delete.useMutation();

  const getDateRange = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (dateRange === "today") {
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      return { start: today, end: tomorrow };
    } else if (dateRange === "week") {
      const weekAgo = new Date(today);
      weekAgo.setDate(weekAgo.getDate() - 7);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      return { start: weekAgo, end: tomorrow };
    } else if (dateRange === "nextWeek") {
      // الأسبوع القادم: من غد إلى غد + 7 أيام
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const nextWeekEnd = new Date(tomorrow);
      nextWeekEnd.setDate(nextWeekEnd.getDate() + 7);
      return { start: tomorrow, end: nextWeekEnd };
    } else if (dateRange === "month") {
      const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      const firstDayOfNextMonth = new Date(today.getFullYear(), today.getMonth() + 1, 1);
      return { start: firstDayOfMonth, end: firstDayOfNextMonth };
    } else if (dateRange === "all") {
      // عرض جميع الحجوزات بدون تصفية زمنية
      return { start: new Date(1970, 0, 1), end: new Date(2099, 11, 31) };
    } else {
      return {
        start: customStartDate ? new Date(customStartDate) : today,
        end: customEndDate ? new Date(customEndDate) : new Date(),
      };
    }
  };

  const filteredBookings = useMemo(() => {
    const now = new Date();
    const { start, end } = getDateRange();

    return (bookings.data || []).filter((booking: any) => {
      const bookingDate = new Date(booking.pickupDateTime);
      const matchesDateRange = bookingDate >= start && bookingDate <= end;
      const matchesSearch = searchText === "" || 
        booking.bookingNumber?.toLowerCase().includes(searchText.toLowerCase()) ||
        booking.customerName?.toLowerCase().includes(searchText.toLowerCase()) ||
        booking.pickupLocation?.toLowerCase().includes(searchText.toLowerCase());

      // استخدام status والفترة الزمنية للفلترة
      if (bookingTab === "all") {
        return matchesSearch && matchesDateRange;
      }

      if (bookingTab === "active") {
        return matchesSearch && matchesDateRange && ["pending", "confirmed", "in_progress"].includes(booking.status);
      } else if (bookingTab === "completed") {
        return matchesSearch && matchesDateRange && booking.status === "completed";
      }
      return matchesSearch && matchesDateRange;
    });
  }, [bookings.data, dateRange, customStartDate, customEndDate, searchText, bookingTab]);

  // حساب الإحصائيات
  const stats = useMemo(() => {
    const data = bookings.data || [];
    const now = new Date();
    
    const totalReceivables = 0;
    return {
      total: data.length,
      active: data.filter((b: any) => new Date(b.pickupDateTime) > now).length,
      completed: data.filter((b: any) => new Date(b.pickupDateTime) <= now).length,
      totalRevenue: data.reduce((sum: number, b: any) => sum + (Number(b.fare) || 0), 0),
      avgFare: data.length > 0 ? data.reduce((sum: number, b: any) => sum + (Number(b.fare) || 0), 0) / data.length : 0,
      totalReceivables: totalReceivables,
    };
  }, [bookings.data]);

  const handleSave = async () => {
    try {
      const dataToSend = {
        ...formData,
        pickupDateTime: new Date(formData.pickupDateTime),
        programEndDate: formData.programEndDate ? new Date(formData.programEndDate) : undefined,
        fare: parseFloat(formData.fare) || 0,
        programDays: parseInt(formData.programDays) || 0,
      };

      if (editingId) {
        await updateBooking.mutateAsync({ id: editingId, ...dataToSend });
        toast.success("تم تحديث الحجز بنجاح");
      } else {
        await createBooking.mutateAsync(dataToSend);
        toast.success("تم إنشاء الحجز بنجاح");
      }

      setIsOpen(false);
      setEditingId(null);
      setFormData({
        clientId: undefined,
        bookingNumber: "",
        customerName: "",
        customerPhone: "",
        customerEmail: "",
        pickupLocation: "",
        dropoffLocation: "",
        pickupDateTime: new Date().toISOString().slice(0, 16),
        fare: "0",
        bookingSource: "internal",
        status: "pending",
        notes: "",
        programDays: "",
        programEndDate: "",
      });
    } catch (error) {
      toast.error(editingId ? "فشل تحديث الحجز" : "فشل إنشاء الحجز");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteBooking.mutateAsync({ id });
      toast.success("تم حذف الحجز بنجاح");
    } catch (error) {
      toast.error("فشل حذف الحجز");
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "confirmed":
        return "bg-blue-100 text-blue-800";
      case "in_progress":
        return "bg-purple-100 text-purple-800";
      case "completed":
        return "bg-green-100 text-green-800";
      case "cancelled":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: "قيد الانتظار",
      confirmed: "مؤكد",
      in_progress: "قيد التنفيذ",
      completed: "مكتمل",
      cancelled: "ملغي",
    };
    return labels[status] || status;
  };

  return (
    <div className="space-y-6 p-6">
      {/* العنوان والزر */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">إدارة الحجوزات</h1>
          <p className="text-gray-600 mt-1">إدارة جميع حجوزات النقل والرحلات السياحية</p>
        </div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 ml-2" />
              حجز جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingId ? "تعديل الحجز" : "إنشاء حجز جديد"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              <div>
                <Label>رقم الحجز</Label>
                <Input
                  value={formData.bookingNumber}
                  onChange={(e) => setFormData({ ...formData, bookingNumber: e.target.value })}
                  placeholder="أدخل رقم الحجز"
                />
              </div>
              <div>
                <Label>العميل</Label>
                <Select value={formData.clientId?.toString() || ""} onValueChange={(value) => {
                  const client = clients.data?.find(c => c.id === parseInt(value));
                  setFormData({
                    ...formData,
                    clientId: parseInt(value),
                    customerName: client?.name || "",
                    customerPhone: client?.phone || "",
                    customerEmail: client?.email || ""
                  });
                }}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر عميل" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.data?.map((client) => (
                      <SelectItem key={client.id} value={client.id.toString()}>
                        {client.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>اسم العميل</Label>
                <Input
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  placeholder="أدخل اسم العميل"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>الهاتف</Label>
                  <Input
                    value={formData.customerPhone}
                    onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                    placeholder="رقم الهاتف"
                  />
                </div>
                <div>
                  <Label>البريد الإلكتروني</Label>
                  <Input
                    value={formData.customerEmail}
                    onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })}
                    placeholder="البريد الإلكتروني"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>من</Label>
                  <Input
                    value={formData.pickupLocation}
                    onChange={(e) => setFormData({ ...formData, pickupLocation: e.target.value })}
                    placeholder="موقع الاستقبال"
                  />
                </div>
                <div>
                  <Label>إلى</Label>
                  <Input
                    value={formData.dropoffLocation}
                    onChange={(e) => setFormData({ ...formData, dropoffLocation: e.target.value })}
                    placeholder="موقع الإنزال"
                  />
                </div>
              </div>
              <div>
                <Label>تاريخ ووقت الاستقبال</Label>
                <Input
                  type="datetime-local"
                  value={formData.pickupDateTime}
                  onChange={(e) => setFormData({ ...formData, pickupDateTime: e.target.value })}
                />
              </div>
              <div>
                <Label>المبلغ</Label>
                <Input
                  type="number"
                  value={formData.fare}
                  onChange={(e) => setFormData({ ...formData, fare: e.target.value })}
                  placeholder="أدخل المبلغ"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>عدد أيام البرنامج</Label>
                  <Input
                    type="number"
                    value={formData.programDays}
                    onChange={(e) => setFormData({ ...formData, programDays: e.target.value })}
                    placeholder="أدخل عدد الأيام"
                  />
                </div>
                <div>
                  <Label>تاريخ انتهاء البرنامج</Label>
                  <Input
                    type="date"
                    value={formData.programEndDate}
                    onChange={(e) => setFormData({ ...formData, programEndDate: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label>الحالة</Label>
                <Select value={formData.status} onValueChange={(value: any) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">قيد الانتظار</SelectItem>
                    <SelectItem value="confirmed">مؤكد</SelectItem>
                    <SelectItem value="in_progress">قيد التنفيذ</SelectItem>
                    <SelectItem value="completed">مكتمل</SelectItem>
                    <SelectItem value="cancelled">ملغى</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2 justify-end pt-4">
                <Button variant="outline" onClick={() => {
                  setIsOpen(false);
                  setEditingId(null);
                }}>إلغاء</Button>
                <Button onClick={() => handleSave()}>حفظ</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* الإحصائيات */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 text-sm">إجمالي الحجوزات</p>
                <p className="text-3xl font-bold mt-2">{stats.total}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 text-sm">الحجوزات النشطة</p>
                <p className="text-3xl font-bold mt-2">{stats.active}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 text-sm">الحجوزات المكتملة</p>
                <p className="text-3xl font-bold mt-2">{stats.completed}</p>
              </div>
              <Users className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 text-sm">إجمالي الإيرادات</p>
                <p className="text-3xl font-bold mt-2">{formatCurrency(stats.totalRevenue)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-emerald-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-gray-600 text-sm">إجمالي الذمم المستحقة</p>
                <p className="text-3xl font-bold mt-2">{formatCurrency(stats.totalReceivables)}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* الفلاتر */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label className="text-sm font-medium">الفترة الزمنية</Label>
              <DateRangeSelect
                value={dateRange}
                onChange={(value: any) => setDateRange(value)}
                options={[
                  { value: "today", label: "اليوم" },
                  { value: "week", label: "الأسبوع الماضي" },
                  { value: "nextWeek", label: "الأسبوع القادم" },
                  { value: "month", label: "هذا الشهر" },
                  { value: "all", label: "الجميع" },
                  { value: "custom", label: "مخصص" },
                ]}
              />
            </div>

            {dateRange === "custom" && (
              <>
                <div>
                  <Label className="text-sm font-medium">من التاريخ</Label>
                  <Input
                    type="date"
                    value={customStartDate}
                    onChange={(e) => setCustomStartDate(e.target.value)}
                  />
                </div>
                <div>
                  <Label className="text-sm font-medium">إلى التاريخ</Label>
                  <Input
                    type="date"
                    value={customEndDate}
                    onChange={(e) => setCustomEndDate(e.target.value)}
                  />
                </div>
              </>
            )}
          </div>

          <div className="mt-4">
            <Label className="text-sm font-medium">البحث</Label>
            <Input
              placeholder="ابحث عن رقم حجز أو اسم عميل..."
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* التبويبات والجدول */}
      <Card>
        <CardContent className="pt-6">
          <Tabs value={bookingTab} onValueChange={(value: any) => setBookingTab(value)}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="active">النشطة</TabsTrigger>
              <TabsTrigger value="all">جميعها</TabsTrigger>
              <TabsTrigger value="completed">المكتملة</TabsTrigger>
            </TabsList>

            <TabsContent value="active" className="mt-4">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>رقم الحجز</TableHead>
                      <TableHead>العميل</TableHead>
                      <TableHead>من</TableHead>
                      <TableHead>إلى</TableHead>
                      <TableHead>التاريخ</TableHead>
                      <TableHead>المبلغ</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead className="text-center">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBookings.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-gray-500 py-8">
                          لا توجد حجوزات نشطة
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredBookings.map((booking: any) => {
                        return (
                          <TableRow key={booking.id}>
                            <TableCell className="font-medium">{booking.bookingNumber}</TableCell>
                            <TableCell>{booking.customerName}</TableCell>
                            <TableCell>{booking.pickupLocation}</TableCell>
                            <TableCell>{booking.dropoffLocation}</TableCell>
                            <TableCell>{formatDateTime(booking.pickupDateTime)}</TableCell>
                            <TableCell>{formatCurrency(booking.fare)}</TableCell>
                            <TableCell>
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(booking.status)}`}>
                                {getStatusLabel(booking.status)}
                              </span>
                            </TableCell>
                            <TableCell className="text-center">
                              <div className="flex justify-center gap-2">
                                <Button variant="ghost" size="sm" onClick={() => {
                                  setFormData({
                                    clientId: booking.clientId,
                                    bookingNumber: booking.bookingNumber,
                                    customerName: booking.customerName,
                                    customerPhone: booking.customerPhone,
                                    customerEmail: booking.customerEmail,
                                    pickupLocation: booking.pickupLocation,
                                    dropoffLocation: booking.dropoffLocation,
                                    pickupDateTime: toDatetimeLocal(booking.pickupDateTime),
                                    fare: booking.fare?.toString() || "0",
                                    bookingSource: booking.bookingSource,
                                    status: booking.status,
                                    notes: booking.notes,
                                    programDays: booking.programDays?.toString() || "",
                                    programEndDate: booking.programEndDate ? new Date(booking.programEndDate).toISOString().split('T')[0] : "",
                                  });
                                  setEditingId(booking.id);
                                  setIsOpen(true);
                                }}>
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => {
                                  setFormData({
                                    clientId: booking.clientId,
                                    bookingNumber: booking.bookingNumber,
                                    customerName: booking.customerName,
                                    customerPhone: booking.customerPhone,
                                    customerEmail: booking.customerEmail,
                                    pickupLocation: booking.pickupLocation,
                                    dropoffLocation: booking.dropoffLocation,
                                    pickupDateTime: toDatetimeLocal(booking.pickupDateTime),
                                    fare: booking.fare?.toString() || "0",
                                    bookingSource: booking.bookingSource,
                                    status: booking.status,
                                    notes: booking.notes,
                                    programDays: booking.programDays?.toString() || "",
                                    programEndDate: booking.programEndDate ? new Date(booking.programEndDate).toISOString().split('T')[0] : "",
                                  });
                                  setEditingId(booking.id);
                                  setIsOpen(true);
                                }}>
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDelete(booking.id)}
                                >
                                  <Trash2 className="w-4 h-4 text-red-500" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="all" className="mt-4">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>رقم الحجز</TableHead>
                      <TableHead>العميل</TableHead>
                      <TableHead>من</TableHead>
                      <TableHead>إلى</TableHead>
                      <TableHead>التاريخ</TableHead>
                      <TableHead>المبلغ</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead className="text-center">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBookings.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-gray-500 py-8">
                          لا توجد حجوزات
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredBookings.map((booking: any) => {
                        return (
                          <TableRow key={booking.id}>
                            <TableCell className="font-medium">{booking.bookingNumber}</TableCell>
                            <TableCell>{booking.customerName}</TableCell>
                            <TableCell>{booking.pickupLocation}</TableCell>
                            <TableCell>{booking.dropoffLocation}</TableCell>
                            <TableCell>{formatDateTime(booking.pickupDateTime)}</TableCell>
                            <TableCell>{formatCurrency(booking.fare)}</TableCell>
                            <TableCell>
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(booking.status)}`}>
                                {getStatusLabel(booking.status)}
                              </span>
                            </TableCell>
                            <TableCell className="text-center">
                              <div className="flex justify-center gap-2">
                                <Button variant="ghost" size="sm" onClick={() => {
                                  setFormData({
                                    clientId: booking.clientId,
                                    bookingNumber: booking.bookingNumber,
                                    customerName: booking.customerName,
                                    customerPhone: booking.customerPhone,
                                    customerEmail: booking.customerEmail,
                                    pickupLocation: booking.pickupLocation,
                                    dropoffLocation: booking.dropoffLocation,
                                    pickupDateTime: toDatetimeLocal(booking.pickupDateTime),
                                    fare: booking.fare?.toString() || "0",
                                    bookingSource: booking.bookingSource,
                                    status: booking.status,
                                    notes: booking.notes,
                                    programDays: booking.programDays?.toString() || "",
                                    programEndDate: booking.programEndDate ? new Date(booking.programEndDate).toISOString().split('T')[0] : "",
                                  });
                                  setEditingId(booking.id);
                                  setIsOpen(true);
                                }}>
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => {
                                  setFormData({
                                    clientId: booking.clientId,
                                    bookingNumber: booking.bookingNumber,
                                    customerName: booking.customerName,
                                    customerPhone: booking.customerPhone,
                                    customerEmail: booking.customerEmail,
                                    pickupLocation: booking.pickupLocation,
                                    dropoffLocation: booking.dropoffLocation,
                                    pickupDateTime: toDatetimeLocal(booking.pickupDateTime),
                                    fare: booking.fare?.toString() || "0",
                                    bookingSource: booking.bookingSource,
                                    status: booking.status,
                                    notes: booking.notes,
                                    programDays: booking.programDays?.toString() || "",
                                    programEndDate: booking.programEndDate ? new Date(booking.programEndDate).toISOString().split('T')[0] : "",
                                  });
                                  setEditingId(booking.id);
                                  setIsOpen(true);
                                }}>
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDelete(booking.id)}
                                >
                                  <Trash2 className="w-4 h-4 text-red-500" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="completed" className="mt-4">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>رقم الحجز</TableHead>
                      <TableHead>العميل</TableHead>
                      <TableHead>من</TableHead>
                      <TableHead>إلى</TableHead>
                      <TableHead>التاريخ</TableHead>
                      <TableHead>المبلغ</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead className="text-center">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBookings.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-gray-500 py-8">
                          لا توجد حجوزات مكتملة
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredBookings.map((booking: any) => {
                        return (
                          <TableRow key={booking.id}>
                            <TableCell className="font-medium">{booking.bookingNumber}</TableCell>
                            <TableCell>{booking.customerName}</TableCell>
                            <TableCell>{booking.pickupLocation}</TableCell>
                            <TableCell>{booking.dropoffLocation}</TableCell>
                            <TableCell>{formatDateTime(booking.pickupDateTime)}</TableCell>
                            <TableCell>{formatCurrency(booking.fare)}</TableCell>
                            <TableCell>
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(booking.status)}`}>
                                {getStatusLabel(booking.status)}
                              </span>
                            </TableCell>
                            <TableCell className="text-center">
                              <div className="flex justify-center gap-2">
                                <Button variant="ghost" size="sm" onClick={() => {
                                  setFormData({
                                    clientId: booking.clientId,
                                    bookingNumber: booking.bookingNumber,
                                    customerName: booking.customerName,
                                    customerPhone: booking.customerPhone,
                                    customerEmail: booking.customerEmail,
                                    pickupLocation: booking.pickupLocation,
                                    dropoffLocation: booking.dropoffLocation,
                                    pickupDateTime: toDatetimeLocal(booking.pickupDateTime),
                                    fare: booking.fare?.toString() || "0",
                                    bookingSource: booking.bookingSource,
                                    status: booking.status,
                                    notes: booking.notes,
                                    programDays: booking.programDays?.toString() || "",
                                    programEndDate: booking.programEndDate ? new Date(booking.programEndDate).toISOString().split('T')[0] : "",
                                  });
                                  setEditingId(booking.id);
                                  setIsOpen(true);
                                }}>
                                  <Eye className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => {
                                  setFormData({
                                    clientId: booking.clientId,
                                    bookingNumber: booking.bookingNumber,
                                    customerName: booking.customerName,
                                    customerPhone: booking.customerPhone,
                                    customerEmail: booking.customerEmail,
                                    pickupLocation: booking.pickupLocation,
                                    dropoffLocation: booking.dropoffLocation,
                                    pickupDateTime: toDatetimeLocal(booking.pickupDateTime),
                                    fare: booking.fare?.toString() || "0",
                                    bookingSource: booking.bookingSource,
                                    status: booking.status,
                                    notes: booking.notes,
                                    programDays: booking.programDays?.toString() || "",
                                    programEndDate: booking.programEndDate ? new Date(booking.programEndDate).toISOString().split('T')[0] : "",
                                  });
                                  setEditingId(booking.id);
                                  setIsOpen(true);
                                }}>
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDelete(booking.id)}
                                >
                                  <Trash2 className="w-4 h-4 text-red-500" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Dialog عرض التتبع */}
      <Dialog open={showTracking} onOpenChange={setShowTracking}>
        <DialogContent className="max-w-4xl max-h-screen overflow-y-auto">
          <DialogHeader>
            <DialogTitle>تتبع المركبة - الحجز #{selectedBookingId}</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            {bookingWithTracking.isLoading ? (
              <div className="text-center py-8">
                <p className="text-gray-600">جاري تحميل بيانات التتبع...</p>
              </div>
            ) : bookingWithTracking.data ? (
              <BookingTrackingMap
                vehicle={bookingWithTracking.data.vehicle}
                tracking={bookingWithTracking.data.tracking}
              />
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-600">لم يتم العثور على بيانات التتبع</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
