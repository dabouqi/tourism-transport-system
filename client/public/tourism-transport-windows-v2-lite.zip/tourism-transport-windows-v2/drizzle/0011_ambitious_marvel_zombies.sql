CREATE TABLE `geofences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`type` enum('circle','polygon') DEFAULT 'circle',
	`centerLatitude` decimal(10,8),
	`centerLongitude` decimal(11,8),
	`radiusMeters` int,
	`polygonPoints` text,
	`alertOnEnter` boolean DEFAULT false,
	`alertOnExit` boolean DEFAULT false,
	`isActive` boolean DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `geofences_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `routeHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`vehicleId` int NOT NULL,
	`bookingId` int,
	`startTime` datetime NOT NULL,
	`endTime` datetime,
	`totalDistance` decimal(10,2),
	`averageSpeed` decimal(5,2),
	`maxSpeed` decimal(5,2),
	`routeData` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `routeHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trackingAlerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`vehicleId` int NOT NULL,
	`bookingId` int,
	`type` varchar(50) NOT NULL,
	`priority` enum('low','medium','high','critical') DEFAULT 'medium',
	`message` text NOT NULL,
	`latitude` decimal(10,8),
	`longitude` decimal(11,8),
	`acknowledged` boolean DEFAULT false,
	`acknowledgedBy` int,
	`acknowledgedAt` datetime,
	`dismissed` boolean DEFAULT false,
	`dismissedBy` int,
	`dismissedAt` datetime,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trackingAlerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `vehicleGeofenceEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`vehicleId` int NOT NULL,
	`geofenceId` int NOT NULL,
	`eventType` enum('enter','exit') NOT NULL,
	`latitude` decimal(10,8) NOT NULL,
	`longitude` decimal(11,8) NOT NULL,
	`timestamp` datetime DEFAULT '2026-01-31 13:21:12.470',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `vehicleGeofenceEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `vehicleLocations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`vehicleId` int NOT NULL,
	`latitude` decimal(10,8) NOT NULL,
	`longitude` decimal(11,8) NOT NULL,
	`speed` decimal(5,2) DEFAULT '0',
	`heading` int DEFAULT 0,
	`status` enum('idle','moving','stopped') DEFAULT 'idle',
	`timestamp` datetime DEFAULT '2026-01-31 13:21:12.470',
	`accuracy` decimal(5,2),
	`altitude` decimal(6,2),
	`batteryLevel` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `vehicleLocations_id` PRIMARY KEY(`id`)
);
