ALTER TABLE `bookings` ADD `programDays` int;--> statement-breakpoint
ALTER TABLE `bookings` ADD `programEndDate` datetime;