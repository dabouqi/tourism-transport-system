ALTER TABLE `transactions` ADD `clientId` int;--> statement-breakpoint
CREATE INDEX `clientId_idx` ON `transactions` (`clientId`);