CREATE TABLE `invoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceNumber` varchar(50) NOT NULL,
	`clientId` int NOT NULL,
	`receivableId` int NOT NULL,
	`bookingId` int NOT NULL,
	`issueDate` datetime NOT NULL,
	`dueDate` datetime,
	`totalAmount` decimal(10,2) NOT NULL,
	`paidAmount` decimal(10,2) DEFAULT '0',
	`remainingAmount` decimal(10,2) NOT NULL,
	`status` enum('draft','sent','viewed','paid','overdue','cancelled') NOT NULL DEFAULT 'draft',
	`paymentMethod` enum('cash','card','transfer','check','other'),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `invoices_id` PRIMARY KEY(`id`),
	CONSTRAINT `invoices_invoiceNumber_unique` UNIQUE(`invoiceNumber`)
);
--> statement-breakpoint
ALTER TABLE `bookings` ADD `clientId` int;