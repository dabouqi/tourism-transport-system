CREATE TABLE `expenseCategories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`color` varchar(20) DEFAULT '#ef4444',
	`icon` varchar(50) DEFAULT 'TrendingDown',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `expenseCategories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `financialSummaries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`year` int NOT NULL,
	`month` int NOT NULL,
	`totalRevenue` decimal(12,2) DEFAULT '0',
	`totalExpenses` decimal(12,2) DEFAULT '0',
	`netProfit` decimal(12,2) DEFAULT '0',
	`profitMargin` decimal(5,2) DEFAULT '0',
	`transactionCount` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `financialSummaries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `incomeCategories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`color` varchar(20) DEFAULT '#10b981',
	`icon` varchar(50) DEFAULT 'TrendingUp',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `incomeCategories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactionsV2` (
	`id` int AUTO_INCREMENT NOT NULL,
	`transactionType` enum('revenue','expense') NOT NULL,
	`incomeCategoryId` int,
	`expenseCategoryId` int,
	`amount` decimal(10,2) NOT NULL,
	`description` text,
	`status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'confirmed',
	`bookingId` int,
	`vehicleId` int,
	`driverId` int,
	`paymentMethod` varchar(50),
	`referenceNumber` varchar(100),
	`notes` text,
	`attachmentUrl` varchar(500),
	`transactionDate` datetime NOT NULL,
	`dueDate` datetime,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transactionsV2_id` PRIMARY KEY(`id`)
);
