CREATE TABLE `externalPartners` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`code` varchar(50) NOT NULL,
	`apiKey` varchar(500),
	`commissionPercentage` decimal(5,2) DEFAULT '0',
	`accountBalance` decimal(12,2) DEFAULT '0',
	`totalEarnings` decimal(12,2) DEFAULT '0',
	`totalCommission` decimal(12,2) DEFAULT '0',
	`status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `externalPartners_id` PRIMARY KEY(`id`),
	CONSTRAINT `externalPartners_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `partnerTransactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`partnerId` int NOT NULL,
	`bookingId` int NOT NULL,
	`externalBookingId` varchar(100) NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`commission` decimal(10,2) DEFAULT '0',
	`netAmount` decimal(10,2) NOT NULL,
	`status` enum('pending','confirmed','paid','cancelled') NOT NULL DEFAULT 'pending',
	`paymentDate` datetime,
	`notes` text,
	`transactionDate` datetime NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `partnerTransactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `bookings` ADD `bookingSource` enum('internal','talixo','get_transfer','transfeero') DEFAULT 'internal' NOT NULL;--> statement-breakpoint
ALTER TABLE `bookings` ADD `externalPartnerBookingId` varchar(100);